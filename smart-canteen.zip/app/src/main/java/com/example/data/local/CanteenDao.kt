package com.example.data.local

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Update
import kotlinx.coroutines.flow.Flow

@Dao
interface MenuItemDao {
    @Query("SELECT * FROM menu_items ORDER BY category ASC, isPopularRushItem DESC, name ASC")
    fun getAllMenuItems(): Flow<List<MenuItemEntity>>

    @Query("SELECT * FROM menu_items WHERE isAvailable = 1 ORDER BY category ASC, name ASC")
    fun getAvailableMenuItems(): Flow<List<MenuItemEntity>>

    @Query("SELECT * FROM menu_items WHERE id = :id")
    suspend fun getMenuItemById(id: Long): MenuItemEntity?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertMenuItems(items: List<MenuItemEntity>)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertMenuItem(item: MenuItemEntity): Long

    @Update
    suspend fun updateMenuItem(item: MenuItemEntity)

    @Query("UPDATE menu_items SET isAvailable = :isAvailable WHERE id = :id")
    suspend fun updateAvailability(id: Long, isAvailable: Boolean)

    @Query("UPDATE menu_items SET stockQuantity = :stock WHERE id = :id")
    suspend fun updateStock(id: Long, stock: Int)

    @Query("DELETE FROM menu_items WHERE id = :id")
    suspend fun deleteMenuItem(id: Long)
}

@Dao
interface OrderDao {
    @Query("SELECT * FROM orders ORDER BY createdAt DESC")
    fun getAllOrders(): Flow<List<OrderEntity>>

    @Query("SELECT * FROM orders WHERE orderStatus NOT IN ('PICKED_UP', 'CANCELLED') ORDER BY CASE WHEN orderType = 'PRIORITY' THEN 0 ELSE 1 END, createdAt ASC")
    fun getActiveKitchenOrders(): Flow<List<OrderEntity>>

    @Query("SELECT * FROM orders WHERE customerName = :customerName ORDER BY createdAt DESC")
    fun getOrdersForCustomer(customerName: String): Flow<List<OrderEntity>>

    @Query("SELECT * FROM orders WHERE orderId = :orderId")
    fun getOrderById(orderId: String): Flow<OrderEntity?>

    @Query("SELECT COUNT(*) FROM orders WHERE orderStatus IN ('PLACED', 'ACCEPTED', 'PREPARING')")
    fun getPendingOrdersCountFlow(): Flow<Int>

    @Query("SELECT COUNT(*) FROM orders WHERE orderStatus IN ('PLACED', 'ACCEPTED', 'PREPARING')")
    suspend fun getPendingOrdersCount(): Int

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertOrder(order: OrderEntity)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertOrders(orders: List<OrderEntity>)

    @Query("UPDATE orders SET orderStatus = :status WHERE orderId = :orderId")
    suspend fun updateOrderStatus(orderId: String, status: String)

    @Query("UPDATE orders SET rating = :rating, reviewComment = :comment WHERE orderId = :orderId")
    suspend fun updateOrderRating(orderId: String, rating: Float, comment: String)

    @Query("SELECT SUM(totalAmount) FROM orders WHERE orderStatus = 'PICKED_UP'")
    fun getTotalRevenueFlow(): Flow<Double?>

    @Query("SELECT SUM(priorityFee) FROM orders WHERE orderStatus = 'PICKED_UP' AND orderType = 'PRIORITY'")
    fun getTotalSurgeRevenueFlow(): Flow<Double?>

    @Query("SELECT COUNT(*) FROM orders WHERE orderType = 'PRIORITY'")
    fun getTotalPriorityOrdersCountFlow(): Flow<Int>
}

@Dao
interface SurgeConfigDao {
    @Query("SELECT * FROM surge_config WHERE id = 1")
    fun getSurgeConfigFlow(): Flow<SurgeConfigEntity?>

    @Query("SELECT * FROM surge_config WHERE id = 1")
    suspend fun getSurgeConfig(): SurgeConfigEntity?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertOrUpdate(config: SurgeConfigEntity)
}

@Dao
interface UserDao {
    @Query("SELECT * FROM users WHERE id = :id")
    fun getUserFlow(id: String): Flow<UserEntity?>

    @Query("SELECT * FROM users WHERE id = :id")
    suspend fun getUser(id: String): UserEntity?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertUser(user: UserEntity)

    @Query("UPDATE users SET walletBalance = :newBalance WHERE id = :id")
    suspend fun updateWalletBalance(id: String, newBalance: Double)

    @Query("UPDATE users SET role = :role WHERE id = :id")
    suspend fun updateUserRole(id: String, role: String)
}

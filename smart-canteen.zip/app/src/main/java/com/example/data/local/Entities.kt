package com.example.data.local

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "menu_items")
data class MenuItemEntity(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,
    val name: String,
    val category: String,
    val description: String,
    val price: Double,
    val dietaryType: String,
    val prepTimeMinutes: Int,
    val stockQuantity: Int,
    val isAvailable: Boolean = true,
    val rating: Float = 4.5f,
    val reviewCount: Int = 28,
    val isPopularRushItem: Boolean = false,
    val iconEmoji: String = "🍲",
    val addOnsJson: String = "" // formatted "Extra Cheese:+20;Spicy Dip:+10"
)

@Entity(tableName = "orders")
data class OrderEntity(
    @PrimaryKey
    val orderId: String,
    val tokenNumber: String,
    val customerName: String,
    val customerPhone: String,
    val orderType: String, // NORMAL, PRIORITY
    val orderStatus: String, // PLACED, ACCEPTED, PREPARING, READY, PICKED_UP
    val itemsJson: String,
    val itemsCount: Int,
    val baseAmount: Double,
    val priorityFee: Double,
    val taxesAndFees: Double,
    val totalAmount: Double,
    val paymentMethod: String,
    val isPaid: Boolean,
    val createdAt: Long,
    val estimatedReadyTime: Long,
    val counterNumber: Int = 1,
    val queuePositionAtOrder: Int = 1,
    val rating: Float = 0f,
    val reviewComment: String = ""
)

@Entity(tableName = "surge_config")
data class SurgeConfigEntity(
    @PrimaryKey
    val id: Int = 1,
    val isSurgeEnabled: Boolean = true,
    val basePriorityFee: Double = 10.0,
    val ordersPerStep: Int = 3,
    val incrementPerStep: Double = 5.0,
    val maxCapFee: Double = 45.0,
    val lunchRushBoost: Double = 10.0,
    val isLunchRushForced: Boolean = false,
    val lastUpdated: Long = System.currentTimeMillis()
)

@Entity(tableName = "users")
data class UserEntity(
    @PrimaryKey
    val id: String,
    val name: String,
    val email: String,
    val phone: String,
    val role: String, // CUSTOMER, STAFF
    val walletBalance: Double,
    val studentId: String
)

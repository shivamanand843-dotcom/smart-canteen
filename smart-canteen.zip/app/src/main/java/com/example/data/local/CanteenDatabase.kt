package com.example.data.local

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase

@Database(
    entities = [
        MenuItemEntity::class,
        OrderEntity::class,
        SurgeConfigEntity::class,
        UserEntity::class
    ],
    version = 1,
    exportSchema = false
)
abstract class CanteenDatabase : RoomDatabase() {
    abstract fun menuItemDao(): MenuItemDao
    abstract fun orderDao(): OrderDao
    abstract fun surgeConfigDao(): SurgeConfigDao
    abstract fun userDao(): UserDao

    companion object {
        @Volatile
        private var INSTANCE: CanteenDatabase? = null

        fun getDatabase(context: Context): CanteenDatabase {
            return INSTANCE ?: synchronized(this) {
                val instance = Room.databaseBuilder(
                    context.applicationContext,
                    CanteenDatabase::class.java,
                    "smart_canteen_database"
                )
                    .fallbackToDestructiveMigration()
                    .build()
                INSTANCE = instance
                instance
            }
        }
    }
}

package com.example.data.model

enum class DietaryType {
    VEG,
    NON_VEG,
    VEGAN,
    BEVERAGE,
    ESSENTIALS
}

enum class OrderType {
    NORMAL,
    PRIORITY
}

enum class OrderStatus {
    PLACED,
    ACCEPTED,
    PREPARING,
    READY,
    PICKED_UP,
    CANCELLED
}

enum class PaymentMethod {
    UPI_GPAY,
    UPI_PHONEPE,
    UPI_PAYTM,
    CAMPUS_WALLET,
    CARD,
    PAY_AT_COUNTER
}

enum class UserRole {
    CUSTOMER,
    STAFF,
    STAFF_ADMIN
}


package com.example.data.model

import com.example.data.local.MenuItemEntity
import com.example.data.local.SurgeConfigEntity

data class CartItem(
    val menuItem: MenuItemEntity,
    val quantity: Int = 1,
    val selectedAddOns: List<AddOnOption> = emptyList(),
    val specialNotes: String = ""
) {
    val singleItemPrice: Double
        get() = menuItem.price + selectedAddOns.sumOf { it.price }

    val totalPrice: Double
        get() = singleItemPrice * quantity
}

data class AddOnOption(
    val name: String,
    val price: Double
)

data class SurgeCalculation(
    val isSurgeEnabled: Boolean,
    val pendingOrdersCount: Int,
    val baseFee: Double,
    val queueStepFee: Double,
    val lunchRushBoost: Double,
    val totalPriorityFee: Double,
    val maxCap: Double,
    val estimatedPriorityPrepMins: Int,
    val estimatedNormalPrepMins: Int,
    val explanation: String
) {
    companion object {
        fun calculate(config: SurgeConfigEntity, pendingOrders: Int): SurgeCalculation {
            if (!config.isSurgeEnabled) {
                return SurgeCalculation(
                    isSurgeEnabled = false,
                    pendingOrdersCount = pendingOrders,
                    baseFee = 0.0,
                    queueStepFee = 0.0,
                    lunchRushBoost = 0.0,
                    totalPriorityFee = 0.0,
                    maxCap = config.maxCapFee,
                    estimatedPriorityPrepMins = 5,
                    estimatedNormalPrepMins = 12 + (pendingOrders * 2),
                    explanation = "Surge pricing is currently paused by canteen administration."
                )
            }

            val baseFee = config.basePriorityFee
            val steps = if (config.ordersPerStep > 0) pendingOrders / config.ordersPerStep else 0
            val queueFee = steps * config.incrementPerStep
            
            // Check if current hour is 12:00 to 14:30 or forced
            val currentHour = java.util.Calendar.getInstance().get(java.util.Calendar.HOUR_OF_DAY)
            val isRushHour = config.isLunchRushForced || (currentHour in 12..14)
            val rushBoost = if (isRushHour) config.lunchRushBoost else 0.0

            val rawTotal = baseFee + queueFee + rushBoost
            val finalFee = rawTotal.coerceAtMost(config.maxCapFee)

            val normalWait = (10 + (pendingOrders * 2.5).toInt()).coerceAtLeast(10)
            val priorityWait = (4 + (pendingOrders * 0.4).toInt()).coerceIn(4, 10)

            val explanation = if (pendingOrders > 0) {
                "₹${baseFee.toInt()} base + ₹${queueFee.toInt()} queue surge (${pendingOrders} orders active)" +
                        (if (rushBoost > 0) " + ₹${rushBoost.toInt()} lunch rush boost" else "") +
                        " = ₹${finalFee.toInt()} (Capped at ₹${config.maxCapFee.toInt()})"
            } else {
                "₹${baseFee.toInt()} base priority fee for instant front-of-queue lane."
            }

            return SurgeCalculation(
                isSurgeEnabled = true,
                pendingOrdersCount = pendingOrders,
                baseFee = baseFee,
                queueStepFee = queueFee,
                lunchRushBoost = rushBoost,
                totalPriorityFee = finalFee,
                maxCap = config.maxCapFee,
                estimatedPriorityPrepMins = priorityWait,
                estimatedNormalPrepMins = normalWait,
                explanation = explanation
            )
        }
    }
}

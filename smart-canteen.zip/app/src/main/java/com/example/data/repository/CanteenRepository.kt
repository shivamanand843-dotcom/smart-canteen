package com.example.data.repository

import com.example.data.local.CanteenDatabase
import com.example.data.local.MenuItemEntity
import com.example.data.local.OrderEntity
import com.example.data.local.SeedData
import com.example.data.local.SurgeConfigEntity
import com.example.data.local.UserEntity
import com.example.data.model.CartItem
import com.example.data.model.OrderStatus
import com.example.data.model.OrderType
import com.example.data.model.PaymentMethod
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.firstOrNull
import kotlinx.coroutines.launch
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import kotlin.random.Random

class CanteenRepository(private val database: CanteenDatabase) {

    private val menuDao = database.menuItemDao()
    private val orderDao = database.orderDao()
    private val surgeDao = database.surgeConfigDao()
    private val userDao = database.userDao()

    init {
        CoroutineScope(Dispatchers.IO).launch {
            seedDatabaseIfEmpty()
        }
    }

    suspend fun seedDatabaseIfEmpty() {
        val existingMenu = menuDao.getAllMenuItems().firstOrNull()
        if (existingMenu.isNullOrEmpty()) {
            menuDao.insertMenuItems(SeedData.initialMenuItems)
            orderDao.insertOrders(SeedData.initialActiveOrders)
            surgeDao.insertOrUpdate(SeedData.defaultSurgeConfig)
            userDao.insertUser(SeedData.defaultUser)
        }
    }

    fun getAllMenuItems(): Flow<List<MenuItemEntity>> = menuDao.getAllMenuItems()
    fun getAvailableMenuItems(): Flow<List<MenuItemEntity>> = menuDao.getAvailableMenuItems()
    
    fun getPendingOrdersCountFlow(): Flow<Int> = orderDao.getPendingOrdersCountFlow()
    suspend fun getPendingOrdersCount(): Int = orderDao.getPendingOrdersCount()

    fun getSurgeConfigFlow(): Flow<SurgeConfigEntity?> = surgeDao.getSurgeConfigFlow()

    fun getActiveKitchenOrders(): Flow<List<OrderEntity>> = orderDao.getActiveKitchenOrders()
    fun getAllOrders(): Flow<List<OrderEntity>> = orderDao.getAllOrders()
    fun getCustomerOrders(name: String): Flow<List<OrderEntity>> = orderDao.getOrdersForCustomer(name)
    fun getOrderById(orderId: String): Flow<OrderEntity?> = orderDao.getOrderById(orderId)

    fun getUserFlow(userId: String = "user_student_1"): Flow<UserEntity?> = userDao.getUserFlow(userId)
    
    fun getTotalRevenueFlow(): Flow<Double?> = orderDao.getTotalRevenueFlow()
    fun getTotalSurgeRevenueFlow(): Flow<Double?> = orderDao.getTotalSurgeRevenueFlow()
    fun getTotalPriorityOrdersCountFlow(): Flow<Int> = orderDao.getTotalPriorityOrdersCountFlow()

    suspend fun placeOrder(
        customerName: String,
        customerPhone: String,
        items: List<CartItem>,
        orderType: OrderType,
        paymentMethod: PaymentMethod,
        priorityFee: Double,
        taxesAndFees: Double
    ): OrderEntity {
        val count = orderDao.getPendingOrdersCount()
        val randomNum = Random.nextInt(10, 99)
        val tokenPrefix = if (orderType == OrderType.PRIORITY) "P" else "C"
        val tokenNumber = "$tokenPrefix-$randomNum"
        val orderId = "ORD-${SimpleDateFormat("HHmm", Locale.US).format(Date())}-$randomNum"

        val itemsSummary = items.joinToString(";") { item ->
            val addonsText = if (item.selectedAddOns.isNotEmpty()) " (${item.selectedAddOns.joinToString { it.name }})" else ""
            "${item.menuItem.name}$addonsText x${item.quantity}"
        }

        val baseAmount = items.sumOf { it.totalPrice }
        val totalAmount = baseAmount + (if (orderType == OrderType.PRIORITY) priorityFee else 0.0) + taxesAndFees

        val estimatedPrepMinutes = if (orderType == OrderType.PRIORITY) {
            (5 + (count * 0.5).toInt()).coerceIn(5, 12)
        } else {
            (12 + (count * 2.5).toInt()).coerceAtLeast(12)
        }

        val counter = if (orderType == OrderType.PRIORITY) 2 else 1 // Counter 2 is Priority Fast Lane

        val order = OrderEntity(
            orderId = orderId,
            tokenNumber = tokenNumber,
            customerName = customerName,
            customerPhone = customerPhone,
            orderType = orderType.name,
            orderStatus = OrderStatus.PLACED.name,
            itemsJson = itemsSummary,
            itemsCount = items.sumOf { it.quantity },
            baseAmount = baseAmount,
            priorityFee = if (orderType == OrderType.PRIORITY) priorityFee else 0.0,
            taxesAndFees = taxesAndFees,
            totalAmount = totalAmount,
            paymentMethod = paymentMethod.name,
            isPaid = paymentMethod != PaymentMethod.PAY_AT_COUNTER,
            createdAt = System.currentTimeMillis(),
            estimatedReadyTime = System.currentTimeMillis() + (estimatedPrepMinutes * 60 * 1000),
            counterNumber = counter,
            queuePositionAtOrder = if (orderType == OrderType.PRIORITY) 1 else (count + 1)
        )

        orderDao.insertOrder(order)

        // Deduct wallet if paid via campus wallet
        if (paymentMethod == PaymentMethod.CAMPUS_WALLET) {
            val user = userDao.getUser("user_student_1")
            if (user != null) {
                val newBal = (user.walletBalance - totalAmount).coerceAtLeast(0.0)
                userDao.updateWalletBalance(user.id, newBal)
            }
        }

        // Reduce stock quantities
        for (item in items) {
            val current = menuDao.getMenuItemById(item.menuItem.id)
            if (current != null) {
                val updatedStock = (current.stockQuantity - item.quantity).coerceAtLeast(0)
                menuDao.updateStock(current.id, updatedStock)
            }
        }

        return order
    }

    suspend fun updateOrderStatus(orderId: String, newStatus: OrderStatus) {
        orderDao.updateOrderStatus(orderId, newStatus.name)
    }

    suspend fun rateOrder(orderId: String, rating: Float, comment: String) {
        orderDao.updateOrderRating(orderId, rating, comment)
    }

    suspend fun updateSurgeConfig(config: SurgeConfigEntity) {
        surgeDao.insertOrUpdate(config.copy(lastUpdated = System.currentTimeMillis()))
    }

    suspend fun updateMenuItemAvailability(id: Long, isAvailable: Boolean) {
        menuDao.updateAvailability(id, isAvailable)
    }

    suspend fun updateMenuItemStock(id: Long, stock: Int) {
        menuDao.updateStock(id, stock)
    }

    suspend fun saveMenuItem(item: MenuItemEntity) {
        if (item.id == 0L) {
            menuDao.insertMenuItem(item)
        } else {
            menuDao.updateMenuItem(item)
        }
    }

    suspend fun deleteMenuItem(id: Long) {
        menuDao.deleteMenuItem(id)
    }

    suspend fun topUpWallet(amount: Double) {
        val user = userDao.getUser("user_student_1") ?: SeedData.defaultUser
        userDao.updateWalletBalance(user.id, user.walletBalance + amount)
    }

    suspend fun updateUserRole(role: String) {
        val user = userDao.getUser("user_student_1") ?: SeedData.defaultUser
        userDao.updateUserRole(user.id, role)
    }

    suspend fun simulateRushOrder() {
        val sampleNames = listOf("Vikram Roy", "Tanvi Sharma", "Ananya Deshmukh", "Kabir Sen", "Riya Kapoor", "Arjun Patel")
        val sampleItems = listOf(
            "Crispy Chicken Zinger Burger x1;Iced Hazelnut Cold Coffee x1",
            "Special Butter Pav Bhaji x2",
            "Classic Masala Dosa x1;Cutting Adrak Masala Chai x2",
            "Paneer Tikka Roll x1;Fresh Mango Lassi x1",
            "Hot Samosa & Mint Chutney (2 pcs) x3"
        )
        val name = sampleNames.random()
        val isPriority = Random.nextBoolean()
        val randomNum = Random.nextInt(40, 99)
        val tokenPrefix = if (isPriority) "P" else "C"
        val order = OrderEntity(
            orderId = "ORD-${SimpleDateFormat("HHmm", Locale.US).format(Date())}-$randomNum",
            tokenNumber = "$tokenPrefix-$randomNum",
            customerName = name,
            customerPhone = "+91 98${Random.nextInt(1000, 9999)} ${Random.nextInt(1000, 9999)}",
            orderType = if (isPriority) "PRIORITY" else "NORMAL",
            orderStatus = "PLACED",
            itemsJson = sampleItems.random(),
            itemsCount = Random.nextInt(1, 4),
            baseAmount = Random.nextInt(80, 220).toDouble(),
            priorityFee = if (isPriority) 25.0 else 0.0,
            taxesAndFees = 10.0,
            totalAmount = (if (isPriority) 25.0 else 0.0) + 10.0 + Random.nextInt(80, 220),
            paymentMethod = if (Random.nextBoolean()) "UPI_GPAY" else "CAMPUS_WALLET",
            isPaid = true,
            createdAt = System.currentTimeMillis(),
            estimatedReadyTime = System.currentTimeMillis() + (12 * 60 * 1000),
            counterNumber = if (isPriority) 2 else 1,
            queuePositionAtOrder = Random.nextInt(1, 6)
        )
        orderDao.insertOrder(order)
    }
}

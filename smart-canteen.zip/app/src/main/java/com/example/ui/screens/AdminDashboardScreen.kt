package com.example.ui.screens

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Analytics
import androidx.compose.material.icons.filled.Bolt
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.Fastfood
import androidx.compose.material.icons.filled.LocalFireDepartment
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Restaurant
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.ShoppingBag
import androidx.compose.material.icons.filled.SwitchAccount
import androidx.compose.material.icons.filled.Tune
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Tab
import androidx.compose.material3.TabRow
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.data.local.MenuItemEntity
import com.example.data.local.OrderEntity
import com.example.data.local.SurgeConfigEntity
import com.example.data.model.DietaryType
import com.example.data.model.OrderStatus
import com.example.data.model.SurgeCalculation
import com.example.data.model.UserRole
import com.example.ui.components.DietaryBadge
import com.example.ui.theme.CanteenOrangePrimary
import com.example.ui.theme.SurgeGold
import com.example.ui.theme.SurgeGoldDark
import com.example.ui.theme.SurgeGoldLight
import com.example.ui.theme.VegGreen
import com.example.ui.viewmodel.CanteenViewModel
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AdminDashboardScreen(
    viewModel: CanteenViewModel,
    onSwitchToCustomer: () -> Unit,
    modifier: Modifier = Modifier
) {
    var selectedTab by remember { mutableIntStateOf(0) }
    val tabs = listOf("Kitchen Queue", "Menu & Stock", "Surge Engine", "Analytics")

    val activeOrders by viewModel.activeKitchenOrders.collectAsStateWithLifecycle()
    val allOrders by viewModel.allOrders.collectAsStateWithLifecycle()
    val menuItems by viewModel.allMenuItems.collectAsStateWithLifecycle()
    val surgeConfig by viewModel.surgeConfig.collectAsStateWithLifecycle()
    val pendingCount by viewModel.pendingOrdersCount.collectAsStateWithLifecycle()
    val surgeCalc by viewModel.surgeCalculation.collectAsStateWithLifecycle()
    val totalRevenue by viewModel.totalRevenue.collectAsStateWithLifecycle()
    val totalSurgeRevenue by viewModel.totalSurgeRevenue.collectAsStateWithLifecycle()
    val totalPriorityCount by viewModel.totalPriorityOrdersCount.collectAsStateWithLifecycle()

    var showAddItemDialog by remember { mutableStateOf(false) }
    var editingItem by remember { mutableStateOf<MenuItemEntity?>(null) }

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Column {
                        Text(
                            text = "Canteen Kitchen & Admin",
                            fontWeight = FontWeight.Black,
                            style = MaterialTheme.typography.titleMedium
                        )
                        Text(
                            text = "Queue: $pendingCount active • Surge: ${if (surgeConfig.isSurgeEnabled) "₹${surgeCalc.totalPriorityFee.toInt()}" else "OFF"}",
                            fontSize = 11.sp,
                            color = CanteenOrangePrimary
                        )
                    }
                },
                actions = {
                    IconButton(
                        onClick = onSwitchToCustomer,
                        modifier = Modifier.testTag("switch_to_customer_button")
                    ) {
                        Icon(
                            imageVector = Icons.Default.SwitchAccount,
                            contentDescription = "Switch to Customer View",
                            tint = CanteenOrangePrimary
                        )
                    }
                }
            )
        }
    ) { paddingValues ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(paddingValues)
        ) {
            // Tabs Bar
            TabRow(
                selectedTabIndex = selectedTab,
                containerColor = MaterialTheme.colorScheme.surface,
                contentColor = CanteenOrangePrimary
            ) {
                tabs.forEachIndexed { index, title ->
                    Tab(
                        selected = selectedTab == index,
                        onClick = { selectedTab = index },
                        text = {
                            Text(
                                text = title,
                                fontSize = 12.sp,
                                fontWeight = if (selectedTab == index) FontWeight.Bold else FontWeight.Normal
                            )
                        }
                    )
                }
            }

            // Tab Content
            when (selectedTab) {
                0 -> KitchenQueueTab(
                    activeOrders = activeOrders,
                    onAdvanceStatus = { orderId, currentStatus ->
                        viewModel.advanceOrderStatus(orderId, currentStatus)
                    },
                    onSimulateRush = { viewModel.simulateIncomingRushOrder() }
                )
                1 -> MenuManagementTab(
                    menuItems = menuItems,
                    onToggleAvailability = { id, current -> viewModel.toggleMenuItemAvailability(id, current) },
                    onUpdateStock = { id, stock -> viewModel.updateMenuItemStock(id, stock) },
                    onEditItem = { item -> editingItem = item },
                    onAddItem = { showAddItemDialog = true },
                    onDeleteItem = { id -> viewModel.deleteMenuItem(id) }
                )
                2 -> SurgeEngineConfigTab(
                    config = surgeConfig,
                    currentPendingCount = pendingCount,
                    onSaveConfig = { updated -> viewModel.updateSurgeConfig(updated) }
                )
                3 -> AnalyticsTab(
                    totalRevenue = totalRevenue,
                    totalSurgeRevenue = totalSurgeRevenue,
                    totalPriorityCount = totalPriorityCount,
                    allOrders = allOrders,
                    menuItems = menuItems
                )
            }
        }

        // Add/Edit Menu Item Dialog
        if (showAddItemDialog || editingItem != null) {
            val itemToEdit = editingItem
            var name by remember { mutableStateOf(itemToEdit?.name ?: "") }
            var category by remember { mutableStateOf(itemToEdit?.category ?: "Fast Food & Snacks") }
            var description by remember { mutableStateOf(itemToEdit?.description ?: "") }
            var priceStr by remember { mutableStateOf(itemToEdit?.price?.toInt()?.toString() ?: "80") }
            var prepTimeStr by remember { mutableStateOf(itemToEdit?.prepTimeMinutes?.toString() ?: "6") }
            var stockStr by remember { mutableStateOf(itemToEdit?.stockQuantity?.toString() ?: "30") }
            var dietaryType by remember { mutableStateOf(itemToEdit?.dietaryType ?: "VEG") }
            var emoji by remember { mutableStateOf(itemToEdit?.iconEmoji ?: "🍔") }

            AlertDialog(
                onDismissRequest = {
                    showAddItemDialog = false
                    editingItem = null
                },
                title = { Text(if (itemToEdit != null) "Edit Menu Item" else "Add New Canteen Item") },
                text = {
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .verticalScroll(rememberScrollState()),
                        verticalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        OutlinedTextField(
                            value = name,
                            onValueChange = { name = it },
                            label = { Text("Item Name") },
                            modifier = Modifier.fillMaxWidth()
                        )
                        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            OutlinedTextField(
                                value = priceStr,
                                onValueChange = { priceStr = it },
                                label = { Text("Price (₹)") },
                                modifier = Modifier.weight(1f)
                            )
                            OutlinedTextField(
                                value = prepTimeStr,
                                onValueChange = { prepTimeStr = it },
                                label = { Text("Prep (Mins)") },
                                modifier = Modifier.weight(1f)
                            )
                        }
                        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            OutlinedTextField(
                                value = stockStr,
                                onValueChange = { stockStr = it },
                                label = { Text("Stock Qty") },
                                modifier = Modifier.weight(1f)
                            )
                            OutlinedTextField(
                                value = emoji,
                                onValueChange = { emoji = it },
                                label = { Text("Emoji") },
                                modifier = Modifier.weight(1f)
                            )
                        }
                        OutlinedTextField(
                            value = description,
                            onValueChange = { description = it },
                            label = { Text("Description") },
                            modifier = Modifier.fillMaxWidth(),
                            maxLines = 2
                        )
                    }
                },
                confirmButton = {
                    Button(
                        onClick = {
                            val newItem = MenuItemEntity(
                                id = itemToEdit?.id ?: 0L,
                                name = name.ifBlank { "Canteen Special" },
                                category = category,
                                description = description.ifBlank { "Freshly prepared in canteen" },
                                price = priceStr.toDoubleOrNull() ?: 50.0,
                                dietaryType = dietaryType,
                                prepTimeMinutes = prepTimeStr.toIntOrNull() ?: 5,
                                stockQuantity = stockStr.toIntOrNull() ?: 20,
                                iconEmoji = emoji.ifBlank { "🍲" }
                            )
                            viewModel.saveMenuItem(newItem)
                            showAddItemDialog = false
                            editingItem = null
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = CanteenOrangePrimary)
                    ) {
                        Text("Save Item", color = Color.White)
                    }
                },
                dismissButton = {
                    TextButton(onClick = {
                        showAddItemDialog = false
                        editingItem = null
                    }) {
                        Text("Cancel")
                    }
                }
            )
        }
    }
}

// ---------------------- TAB 1: KITCHEN QUEUE ----------------------
@Composable
fun KitchenQueueTab(
    activeOrders: List<OrderEntity>,
    onAdvanceStatus: (orderId: String, currentStatus: String) -> Unit,
    onSimulateRush: () -> Unit
) {
    var filterStatus by remember { mutableStateOf("ALL") }

    val filteredList = remember(activeOrders, filterStatus) {
        when (filterStatus) {
            "PRIORITY_ONLY" -> activeOrders.filter { it.orderType == "PRIORITY" }
            "PLACED" -> activeOrders.filter { it.orderStatus == "PLACED" }
            "ACCEPTED" -> activeOrders.filter { it.orderStatus == "ACCEPTED" }
            "PREPARING" -> activeOrders.filter { it.orderStatus == "PREPARING" }
            "READY" -> activeOrders.filter { it.orderStatus == "READY" }
            else -> activeOrders
        }
    }

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .padding(horizontal = 16.dp, vertical = 8.dp)
            .testTag("admin_kitchen_queue"),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        // Simulator banner
        item {
            Card(
                modifier = Modifier.fillMaxWidth(),
                colors = CardDefaults.cardColors(containerColor = Color(0xFFFEF3C7)),
                shape = RoundedCornerShape(12.dp),
                border = androidx.compose.foundation.BorderStroke(1.dp, Color(0xFFFDE68A))
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(12.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            text = "Live Queue Testing & Demo",
                            fontWeight = FontWeight.Bold,
                            fontSize = 13.sp,
                            color = Color(0xFF78350F)
                        )
                        Text(
                            text = "Simulate rush orders to see the dynamic surge engine scale fees.",
                            fontSize = 11.sp,
                            color = Color(0xFF92400E)
                        )
                    }
                    Button(
                        onClick = onSimulateRush,
                        modifier = Modifier.testTag("simulate_order_button"),
                        colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFEA580C)),
                        shape = RoundedCornerShape(8.dp)
                    ) {
                        Text("+ Rush Order", fontSize = 12.sp, color = Color.White, fontWeight = FontWeight.Bold)
                    }
                }
            }
        }

        // Filter chips
        item {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .horizontalScroll(rememberScrollState()),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                listOf("ALL", "PRIORITY_ONLY", "PLACED", "ACCEPTED", "PREPARING", "READY").forEach { status ->
                    val isSelected = filterStatus == status
                    FilterChip(
                        selected = isSelected,
                        onClick = { filterStatus = status },
                        label = {
                            Text(
                                text = if (status == "PRIORITY_ONLY") "⚡ Priority Lane" else status,
                                fontSize = 11.sp,
                                fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal
                            )
                        },
                        colors = FilterChipDefaults.filterChipColors(
                            selectedContainerColor = if (status == "PRIORITY_ONLY") Color(0xFFEA580C) else CanteenOrangePrimary,
                            selectedLabelColor = Color.White
                        )
                    )
                }
            }
        }

        if (filteredList.isEmpty()) {
            item {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(32.dp),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Text(text = "🎉", fontSize = 48.sp)
                    Spacer(modifier = Modifier.height(10.dp))
                    Text("Kitchen Queue is Clear!", fontWeight = FontWeight.Bold)
                    Text("No pending orders under this filter.", fontSize = 12.sp, color = Color(0xFF64748B))
                }
            }
        } else {
            items(filteredList, key = { it.orderId }) { order ->
                val isPriority = order.orderType == "PRIORITY"

                Card(
                    modifier = Modifier.fillMaxWidth(),
                    colors = CardDefaults.cardColors(
                        containerColor = if (isPriority) Color(0xFFFFFBEB) else MaterialTheme.colorScheme.surface
                    ),
                    shape = RoundedCornerShape(14.dp),
                    border = androidx.compose.foundation.BorderStroke(
                        width = if (isPriority) 2.dp else 1.dp,
                        color = if (isPriority) Color(0xFFEA580C) else Color(0xFFE2E8F0)
                    )
                ) {
                    Column(modifier = Modifier.padding(14.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Text(
                                    text = "Token #${order.tokenNumber}",
                                    fontWeight = FontWeight.Black,
                                    fontSize = 17.sp,
                                    color = if (isPriority) Color(0xFFC2410C) else MaterialTheme.colorScheme.onSurface
                                )
                                if (isPriority) {
                                    Spacer(modifier = Modifier.width(6.dp))
                                    Surface(
                                        color = Color(0xFFEA580C),
                                        shape = RoundedCornerShape(6.dp)
                                    ) {
                                        Text(
                                            text = "⚡ EXPRESS #2",
                                            color = Color.White,
                                            fontSize = 9.sp,
                                            fontWeight = FontWeight.ExtraBold,
                                            modifier = Modifier.padding(horizontal = 5.dp, vertical = 2.dp)
                                        )
                                    }
                                }
                            }

                            Surface(
                                color = when (order.orderStatus) {
                                    "READY" -> Color(0xFFDCFCE7)
                                    "PREPARING" -> Color(0xFFFFEDD5)
                                    else -> Color(0xFFFEF3C7)
                                },
                                shape = RoundedCornerShape(6.dp)
                            ) {
                                Text(
                                    text = order.orderStatus,
                                    fontSize = 10.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = when (order.orderStatus) {
                                        "READY" -> VegGreen
                                        "PREPARING" -> Color(0xFFC2410C)
                                        else -> Color(0xFFB45309)
                                    },
                                    modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                                )
                            }
                        }

                        Spacer(modifier = Modifier.height(6.dp))

                        Text(
                            text = "Customer: ${order.customerName} (${order.customerPhone})",
                            fontSize = 12.sp,
                            fontWeight = FontWeight.SemiBold,
                            color = Color(0xFF475569)
                        )

                        Spacer(modifier = Modifier.height(4.dp))

                        Text(
                            text = order.itemsJson.replace(";", "\n"),
                            fontSize = 13.sp,
                            fontWeight = FontWeight.Medium,
                            color = Color(0xFF1E293B)
                        )

                        Spacer(modifier = Modifier.height(10.dp))
                        HorizontalDivider()
                        Spacer(modifier = Modifier.height(10.dp))

                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                text = "Paid: ₹${order.totalAmount.toInt()}" + if (order.priorityFee > 0) " (incl. ₹${order.priorityFee.toInt()} surge)" else "",
                                fontSize = 12.sp,
                                color = Color(0xFF64748B)
                            )

                            // Action button to advance status
                            val nextActionLabel = when (order.orderStatus) {
                                "PLACED" -> "Accept Order"
                                "ACCEPTED" -> "Start Cooking"
                                "PREPARING" -> "Mark Ready 🔔"
                                "READY" -> "Mark Picked Up"
                                else -> "Completed"
                            }

                            Button(
                                onClick = { onAdvanceStatus(order.orderId, order.orderStatus) },
                                colors = ButtonDefaults.buttonColors(
                                    containerColor = if (order.orderStatus == "PREPARING") VegGreen else CanteenOrangePrimary
                                ),
                                shape = RoundedCornerShape(8.dp)
                            ) {
                                Text(
                                    text = nextActionLabel,
                                    fontSize = 12.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = Color.White
                                )
                            }
                        }
                    }
                }
            }
        }
    }
}

// ---------------------- TAB 2: MENU & STOCK MANAGEMENT ----------------------
@Composable
fun MenuManagementTab(
    menuItems: List<MenuItemEntity>,
    onToggleAvailability: (id: Long, currentAvailable: Boolean) -> Unit,
    onUpdateStock: (id: Long, newStock: Int) -> Unit,
    onEditItem: (MenuItemEntity) -> Unit,
    onAddItem: () -> Unit,
    onDeleteItem: (id: Long) -> Unit
) {
    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .padding(horizontal = 16.dp, vertical = 8.dp)
            .testTag("admin_menu_management"),
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "All Menu Items (${menuItems.size})",
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.Bold
                )
                Button(
                    onClick = onAddItem,
                    colors = ButtonDefaults.buttonColors(containerColor = CanteenOrangePrimary),
                    shape = RoundedCornerShape(8.dp)
                ) {
                    Icon(imageVector = Icons.Default.Add, contentDescription = null, modifier = Modifier.size(16.dp))
                    Spacer(modifier = Modifier.width(4.dp))
                    Text("Add Item", fontSize = 12.sp)
                }
            }
        }

        items(menuItems, key = { it.id }) { item ->
            Card(
                modifier = Modifier.fillMaxWidth(),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                shape = RoundedCornerShape(12.dp),
                elevation = CardDefaults.cardElevation(defaultElevation = 1.dp)
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(12.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(text = item.iconEmoji, fontSize = 28.sp)
                    Spacer(modifier = Modifier.width(10.dp))

                    Column(modifier = Modifier.weight(1f)) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            DietaryBadge(dietaryType = item.dietaryType)
                            Spacer(modifier = Modifier.width(6.dp))
                            Text(text = item.name, fontWeight = FontWeight.Bold, fontSize = 14.sp)
                        }
                        Text(
                            text = "₹${item.price.toInt()} • ${item.prepTimeMinutes}m prep • Stock: ${item.stockQuantity}",
                            fontSize = 12.sp,
                            color = Color(0xFF64748B)
                        )
                    }

                    // Stock Quick Stepper & Availability Switch
                    Column(horizontalAlignment = Alignment.End) {
                        Switch(
                            checked = item.isAvailable && item.stockQuantity > 0,
                            onCheckedChange = { onToggleAvailability(item.id, item.isAvailable) },
                            colors = SwitchDefaults.colors(checkedThumbColor = VegGreen)
                        )
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            IconButton(
                                onClick = { onUpdateStock(item.id, (item.stockQuantity - 5).coerceAtLeast(0)) },
                                modifier = Modifier.size(24.dp)
                            ) {
                                Text("-5", fontSize = 10.sp, fontWeight = FontWeight.Bold)
                            }
                            IconButton(
                                onClick = { onUpdateStock(item.id, item.stockQuantity + 5) },
                                modifier = Modifier.size(24.dp)
                            ) {
                                Text("+5", fontSize = 10.sp, fontWeight = FontWeight.Bold)
                            }
                            IconButton(
                                onClick = { onEditItem(item) },
                                modifier = Modifier.size(24.dp)
                            ) {
                                Icon(imageVector = Icons.Default.Edit, contentDescription = "Edit", modifier = Modifier.size(14.dp))
                            }
                        }
                    }
                }
            }
        }
    }
}

// ---------------------- TAB 3: SURGE PRICING ENGINE ----------------------
@Composable
fun SurgeEngineConfigTab(
    config: SurgeConfigEntity,
    currentPendingCount: Int,
    onSaveConfig: (SurgeConfigEntity) -> Unit
) {
    var isEnabled by remember(config) { mutableStateOf(config.isSurgeEnabled) }
    var baseFee by remember(config) { mutableFloatStateOf(config.basePriorityFee.toFloat()) }
    var ordersPerStep by remember(config) { mutableFloatStateOf(config.ordersPerStep.toFloat()) }
    var incrementPerStep by remember(config) { mutableFloatStateOf(config.incrementPerStep.toFloat()) }
    var maxCap by remember(config) { mutableFloatStateOf(config.maxCapFee.toFloat()) }
    var isLunchRushForced by remember(config) { mutableStateOf(config.isLunchRushForced) }
    var lunchBoost by remember(config) { mutableFloatStateOf(config.lunchRushBoost.toFloat()) }

    // Formula Simulator Sandbox Slider
    var simulatedOrdersCount by remember { mutableIntStateOf(currentPendingCount) }

    val simulatedCalculation = remember(isEnabled, baseFee, ordersPerStep, incrementPerStep, maxCap, isLunchRushForced, lunchBoost, simulatedOrdersCount) {
        val currentHour = java.util.Calendar.getInstance().get(java.util.Calendar.HOUR_OF_DAY)
        val isRush = isLunchRushForced || (currentHour in 12..14)
        val steps = if (ordersPerStep > 0) simulatedOrdersCount / ordersPerStep.toInt() else 0
        val queueFee = steps * incrementPerStep
        val boost = if (isRush) lunchBoost else 0.0f
        val raw = if (isEnabled) baseFee + queueFee + boost else 0.0f
        raw.coerceAtMost(maxCap)
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp)
            .verticalScroll(rememberScrollState()),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        // Master Toggle
        Card(
            modifier = Modifier.fillMaxWidth(),
            colors = CardDefaults.cardColors(
                containerColor = if (isEnabled) Color(0xFFFFFBEB) else Color(0xFFF1F5F9)
            ),
            shape = RoundedCornerShape(14.dp)
        ) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(16.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column(modifier = Modifier.weight(1f)) {
                    Text(
                        text = "Dynamic Surge Pricing Engine",
                        fontWeight = FontWeight.Bold,
                        fontSize = 15.sp,
                        color = if (isEnabled) Color(0xFF78350F) else Color(0xFF334155)
                    )
                    Text(
                        text = if (isEnabled) "Active: Surge price adjusts with kitchen queue" else "Disabled: Flat or free queue",
                        fontSize = 12.sp,
                        color = Color(0xFF64748B)
                    )
                }
                Switch(
                    checked = isEnabled,
                    onCheckedChange = { isEnabled = it },
                    colors = SwitchDefaults.colors(checkedThumbColor = Color(0xFFEA580C))
                )
            }
        }

        // Formula Parameters
        Card(
            modifier = Modifier.fillMaxWidth(),
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
            shape = RoundedCornerShape(14.dp)
        ) {
            Column(modifier = Modifier.padding(16.dp)) {
                Text(
                    text = "Surge Pricing Formula Rules",
                    style = MaterialTheme.typography.titleSmall,
                    fontWeight = FontWeight.Bold
                )
                Spacer(modifier = Modifier.height(12.dp))

                // Base Fee
                Text(text = "Base Priority Fee: ₹${baseFee.toInt()}", fontSize = 13.sp, fontWeight = FontWeight.SemiBold)
                Slider(
                    value = baseFee,
                    onValueChange = { baseFee = it },
                    valueRange = 0f..30f,
                    steps = 5,
                    colors = SliderDefaults.colors(thumbColor = CanteenOrangePrimary, activeTrackColor = CanteenOrangePrimary)
                )

                // Step Size
                Text(text = "Queue Step Size: Every ${ordersPerStep.toInt()} pending orders", fontSize = 13.sp, fontWeight = FontWeight.SemiBold)
                Slider(
                    value = ordersPerStep,
                    onValueChange = { ordersPerStep = it },
                    valueRange = 1f..10f,
                    steps = 8,
                    colors = SliderDefaults.colors(thumbColor = CanteenOrangePrimary, activeTrackColor = CanteenOrangePrimary)
                )

                // Increment per step
                Text(text = "Fee Increment per Step: +₹${incrementPerStep.toInt()}", fontSize = 13.sp, fontWeight = FontWeight.SemiBold)
                Slider(
                    value = incrementPerStep,
                    onValueChange = { incrementPerStep = it },
                    valueRange = 2f..20f,
                    steps = 8,
                    colors = SliderDefaults.colors(thumbColor = CanteenOrangePrimary, activeTrackColor = CanteenOrangePrimary)
                )

                // Maximum Cap
                Text(text = "Maximum Priority Fee Cap: ₹${maxCap.toInt()}", fontSize = 13.sp, fontWeight = FontWeight.SemiBold)
                Slider(
                    value = maxCap,
                    onValueChange = { maxCap = it },
                    valueRange = 20f..100f,
                    steps = 15,
                    colors = SliderDefaults.colors(thumbColor = CanteenOrangePrimary, activeTrackColor = CanteenOrangePrimary)
                )

                // Lunch Rush Window
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column {
                        Text(text = "Lunch Rush Auto-Boost (+₹${lunchBoost.toInt()})", fontSize = 13.sp, fontWeight = FontWeight.SemiBold)
                        Text(text = "Force active or auto 12:00 PM - 2:30 PM", fontSize = 11.sp, color = Color(0xFF64748B))
                    }
                    Switch(
                        checked = isLunchRushForced,
                        onCheckedChange = { isLunchRushForced = it }
                    )
                }
            }
        }

        // Live Interactive Formula Sandbox Simulator
        Card(
            modifier = Modifier.fillMaxWidth(),
            colors = CardDefaults.cardColors(containerColor = Color(0xFFF8FAFC)),
            shape = RoundedCornerShape(14.dp),
            border = androidx.compose.foundation.BorderStroke(1.dp, Color(0xFFCBD5E1))
        ) {
            Column(modifier = Modifier.padding(16.dp)) {
                Text(
                    text = "🧪 Interactive Formula Sandbox",
                    style = MaterialTheme.typography.titleSmall,
                    fontWeight = FontWeight.Bold
                )
                Text(
                    text = "Drag slider to test how the priority price calculates for different rush levels.",
                    fontSize = 11.sp,
                    color = Color(0xFF64748B)
                )
                Spacer(modifier = Modifier.height(10.dp))

                Text(
                    text = "Simulated Pending Orders: $simulatedOrdersCount orders",
                    fontWeight = FontWeight.Bold,
                    fontSize = 13.sp
                )
                Slider(
                    value = simulatedOrdersCount.toFloat(),
                    onValueChange = { simulatedOrdersCount = it.toInt() },
                    valueRange = 0f..50f,
                    steps = 49
                )

                Surface(
                    color = Color(0xFFEA580C),
                    shape = RoundedCornerShape(10.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Row(
                        modifier = Modifier.padding(12.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = "Resulting Priority Surge Fee:",
                            color = Color.White,
                            fontWeight = FontWeight.Bold,
                            fontSize = 13.sp
                        )
                        Text(
                            text = "₹${simulatedCalculation.toInt()}",
                            color = Color.White,
                            fontWeight = FontWeight.Black,
                            fontSize = 18.sp
                        )
                    }
                }
            }
        }

        // Save Configuration Button
        Button(
            onClick = {
                onSaveConfig(
                    SurgeConfigEntity(
                        id = 1,
                        isSurgeEnabled = isEnabled,
                        basePriorityFee = baseFee.toDouble(),
                        ordersPerStep = ordersPerStep.toInt(),
                        incrementPerStep = incrementPerStep.toDouble(),
                        maxCapFee = maxCap.toDouble(),
                        lunchRushBoost = lunchBoost.toDouble(),
                        isLunchRushForced = isLunchRushForced,
                        lastUpdated = System.currentTimeMillis()
                    )
                )
            },
            modifier = Modifier
                .fillMaxWidth()
                .height(48.dp)
                .testTag("save_surge_config_button"),
            colors = ButtonDefaults.buttonColors(containerColor = CanteenOrangePrimary),
            shape = RoundedCornerShape(12.dp)
        ) {
            Text("Save Surge Configuration", fontWeight = FontWeight.Bold, color = Color.White)
        }
    }
}

// ---------------------- TAB 4: SALES & QUEUE ANALYTICS ----------------------
@Composable
fun AnalyticsTab(
    totalRevenue: Double,
    totalSurgeRevenue: Double,
    totalPriorityCount: Int,
    allOrders: List<OrderEntity>,
    menuItems: List<MenuItemEntity>
) {
    val totalOrdersCount = allOrders.size
    val prioritySharePercent = if (totalOrdersCount > 0) (totalPriorityCount * 100) / totalOrdersCount else 0

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp)
            .testTag("admin_analytics_view"),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        item {
            Text(
                text = "Daily Sales & Rush Analytics",
                style = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.Bold
            )
        }

        // Metrics Grid (2x2)
        item {
            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                AnalyticsMetricCard(
                    title = "Total Revenue",
                    value = "₹${totalRevenue.toInt()}",
                    subtitle = "$totalOrdersCount orders placed",
                    modifier = Modifier.weight(1f)
                )
                AnalyticsMetricCard(
                    title = "Surge Revenue",
                    value = "₹${totalSurgeRevenue.toInt()}",
                    subtitle = "From priority orders",
                    valueColor = Color(0xFFEA580C),
                    modifier = Modifier.weight(1f)
                )
            }
        }

        item {
            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                AnalyticsMetricCard(
                    title = "Priority Orders",
                    value = "$totalPriorityCount ($prioritySharePercent%)",
                    subtitle = "Fast lane skip crowd",
                    modifier = Modifier.weight(1f)
                )
                AnalyticsMetricCard(
                    title = "Avg Prep Time",
                    value = "6.4 mins",
                    subtitle = "3.2m for priority lane",
                    modifier = Modifier.weight(1f)
                )
            }
        }

        // Peak Rush Distribution Chart (Visual Bars)
        item {
            Card(
                modifier = Modifier.fillMaxWidth(),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                shape = RoundedCornerShape(14.dp)
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Text(
                        text = "Peak Rush Hour Distribution",
                        style = MaterialTheme.typography.titleSmall,
                        fontWeight = FontWeight.Bold
                    )
                    Spacer(modifier = Modifier.height(12.dp))

                    PeakHourBar(timeSlot = "08:30 - 10:30 AM (Breakfast Rush)", fillRatio = 0.45f, ordersCount = 28, feeAvg = "₹10")
                    PeakHourBar(timeSlot = "12:00 - 02:30 PM (Lunch Rush 🔥)", fillRatio = 0.95f, ordersCount = 84, feeAvg = "₹25")
                    PeakHourBar(timeSlot = "04:30 - 06:30 PM (Evening Snacks)", fillRatio = 0.65f, ordersCount = 42, feeAvg = "₹15")
                    PeakHourBar(timeSlot = "07:30 - 09:30 PM (Dinner / Night)", fillRatio = 0.35f, ordersCount = 19, feeAvg = "₹10")
                }
            }
        }

        // Best-Selling Items Leaderboard
        item {
            Card(
                modifier = Modifier.fillMaxWidth(),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                shape = RoundedCornerShape(14.dp)
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Text(
                        text = "Best-Selling Canteen Favorites",
                        style = MaterialTheme.typography.titleSmall,
                        fontWeight = FontWeight.Bold
                    )
                    Spacer(modifier = Modifier.height(10.dp))

                    menuItems.take(5).forEachIndexed { index, item ->
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(vertical = 4.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Text(
                                    text = "#${index + 1}",
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 12.sp,
                                    color = Color(0xFF64748B)
                                )
                                Spacer(modifier = Modifier.width(8.dp))
                                Text(text = "${item.iconEmoji} ${item.name}", fontSize = 13.sp, fontWeight = FontWeight.Medium)
                            }
                            Text(text = "₹${item.price.toInt()}", fontWeight = FontWeight.Bold, fontSize = 13.sp, color = CanteenOrangePrimary)
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun AnalyticsMetricCard(
    title: String,
    value: String,
    subtitle: String,
    modifier: Modifier = Modifier,
    valueColor: Color = MaterialTheme.colorScheme.onSurface
) {
    Card(
        modifier = modifier,
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        shape = RoundedCornerShape(12.dp),
        elevation = CardDefaults.cardElevation(defaultElevation = 1.dp)
    ) {
        Column(modifier = Modifier.padding(14.dp)) {
            Text(text = title, fontSize = 11.sp, color = Color(0xFF64748B), fontWeight = FontWeight.SemiBold)
            Spacer(modifier = Modifier.height(4.dp))
            Text(text = value, fontSize = 18.sp, fontWeight = FontWeight.Black, color = valueColor)
            Spacer(modifier = Modifier.height(2.dp))
            Text(text = subtitle, fontSize = 10.sp, color = Color(0xFF94A3B8))
        }
    }
}

@Composable
fun PeakHourBar(
    timeSlot: String,
    fillRatio: Float,
    ordersCount: Int,
    feeAvg: String
) {
    Column(modifier = Modifier.padding(vertical = 4.dp)) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Text(text = timeSlot, fontSize = 11.sp, fontWeight = FontWeight.Medium)
            Text(text = "$ordersCount orders • avg surge $feeAvg", fontSize = 10.sp, color = Color(0xFF64748B))
        }
        Spacer(modifier = Modifier.height(3.dp))
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .height(8.dp)
                .clip(RoundedCornerShape(4.dp))
                .background(Color(0xFFE2E8F0))
        ) {
            Box(
                modifier = Modifier
                    .fillMaxWidth(fillRatio)
                    .height(8.dp)
                    .clip(RoundedCornerShape(4.dp))
                    .background(if (fillRatio > 0.8f) Color(0xFFEA580C) else CanteenOrangePrimary)
            )
        }
    }
}

package com.example.ui.components

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Bolt
import androidx.compose.material.icons.filled.KeyboardArrowDown
import androidx.compose.material.icons.filled.KeyboardArrowUp
import androidx.compose.material.icons.filled.LocalFireDepartment
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.SurgeCalculation
import com.example.ui.theme.PriorityDarkCard
import com.example.ui.theme.PrioritySubCard
import com.example.ui.theme.SurgeHighlightText
import com.example.ui.theme.SurgePillBg
import com.example.ui.theme.SurgePillText

@Composable
fun SurgeBannerCard(
    surge: SurgeCalculation,
    modifier: Modifier = Modifier,
    onSimulateClick: (() -> Unit)? = null
) {
    var isExpanded by remember { mutableStateOf(false) }
    val isHighRush = surge.pendingOrdersCount >= 6

    Card(
        modifier = modifier
            .fillMaxWidth()
            .testTag("surge_banner_card")
            .clip(RoundedCornerShape(24.dp))
            .border(
                width = 1.dp,
                color = Color(0xFFEADDFF).copy(alpha = 0.2f),
                shape = RoundedCornerShape(24.dp)
            ),
        colors = CardDefaults.cardColors(containerColor = PriorityDarkCard)
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(20.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.Top,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Column(modifier = Modifier.weight(1f)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text(
                            text = if (isHighRush) "🔥 Priority Rush" else "🚀 Priority Pickup",
                            fontSize = 17.sp,
                            fontWeight = FontWeight.Bold,
                            color = Color.White
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Surface(
                            color = SurgePillBg,
                            shape = RoundedCornerShape(4.dp)
                        ) {
                            Text(
                                text = if (isHighRush) "SURGE" else "FAST LANE",
                                color = SurgePillText,
                                fontSize = 10.sp,
                                fontWeight = FontWeight.Black,
                                modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                            )
                        }
                    }
                    Spacer(modifier = Modifier.height(4.dp))
                    Text(
                        text = if (surge.pendingOrdersCount > 0)
                            "Lunch Rush: ${surge.pendingOrdersCount} orders ahead of you"
                        else
                            "Standard queue is clear • Express Lane available",
                        fontSize = 12.sp,
                        color = Color(0xFFEADDFF)
                    )
                }

                Column(horizontalAlignment = Alignment.End) {
                    Text(
                        text = "+₹${surge.totalPriorityFee.toInt()}",
                        fontSize = 20.sp,
                        fontWeight = FontWeight.Black,
                        color = SurgeHighlightText
                    )
                    Text(
                        text = if (isExpanded) "Hide" else "Why?",
                        fontSize = 11.sp,
                        fontWeight = FontWeight.SemiBold,
                        color = Color(0xFFD0BCFF),
                        modifier = Modifier
                            .clickable { isExpanded = !isExpanded }
                            .padding(top = 2.dp)
                    )
                }
            }

            Spacer(modifier = Modifier.height(16.dp))

            // Time estimate cards
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                // Normal Queue Card
                Column(
                    modifier = Modifier
                        .weight(1f)
                        .background(PrioritySubCard, RoundedCornerShape(16.dp))
                        .border(1.dp, Color(0xFFEADDFF).copy(alpha = 0.15f), RoundedCornerShape(16.dp))
                        .padding(12.dp)
                ) {
                    Text(
                        text = "NORMAL QUEUE",
                        fontSize = 10.sp,
                        fontWeight = FontWeight.SemiBold,
                        letterSpacing = 1.sp,
                        color = Color(0xFFEADDFF).copy(alpha = 0.7f)
                    )
                    Spacer(modifier = Modifier.height(2.dp))
                    Text(
                        text = "~${surge.estimatedNormalPrepMins} mins",
                        fontSize = 14.sp,
                        fontWeight = FontWeight.Bold,
                        color = Color.White
                    )
                }

                // Priority Card
                Column(
                    modifier = Modifier
                        .weight(1f)
                        .background(Color(0xFFEADDFF), RoundedCornerShape(16.dp))
                        .border(2.dp, Color.White, RoundedCornerShape(16.dp))
                        .padding(12.dp)
                ) {
                    Text(
                        text = "PRIORITY",
                        fontSize = 10.sp,
                        fontWeight = FontWeight.Bold,
                        letterSpacing = 1.sp,
                        color = PriorityDarkCard
                    )
                    Spacer(modifier = Modifier.height(2.dp))
                    Text(
                        text = "~${surge.estimatedPriorityPrepMins} mins",
                        fontSize = 14.sp,
                        fontWeight = FontWeight.Bold,
                        color = PriorityDarkCard
                    )
                }
            }

            // Expanded Breakdown
            AnimatedVisibility(visible = isExpanded) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(top = 12.dp)
                        .background(PrioritySubCard, RoundedCornerShape(16.dp))
                        .padding(14.dp)
                ) {
                    Text(
                        text = "Transparent Dynamic Pricing",
                        fontSize = 13.sp,
                        fontWeight = FontWeight.Bold,
                        color = Color.White
                    )
                    Spacer(modifier = Modifier.height(4.dp))
                    Text(
                        text = "Base fee: ₹${surge.baseFee.toInt()} + Demand step: ₹${surge.queueStepFee.toInt()}" +
                                if (surge.lunchRushBoost > 0) " + Rush boost: ₹${surge.lunchRushBoost.toInt()}" else "",
                        fontSize = 12.sp,
                        color = Color(0xFFEADDFF)
                    )
                    Spacer(modifier = Modifier.height(4.dp))
                    Text(
                        text = "Priority orders receive expedited prep at Counter #2 (Express Pickup Lane).",
                        fontSize = 11.sp,
                        color = Color(0xFFEADDFF).copy(alpha = 0.8f)
                    )
                }
            }
        }
    }
}


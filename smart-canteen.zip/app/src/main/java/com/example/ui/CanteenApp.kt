package com.example.ui

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AdminPanelSettings
import androidx.compose.material.icons.filled.History
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.ReceiptLong
import androidx.compose.material.icons.filled.RestaurantMenu
import androidx.compose.material.icons.filled.ShoppingBag
import androidx.compose.material.icons.outlined.History
import androidx.compose.material.icons.outlined.Person
import androidx.compose.material.icons.outlined.RestaurantMenu
import androidx.compose.material.icons.outlined.ShoppingBag
import androidx.compose.material3.Badge
import androidx.compose.material3.BadgedBox
import androidx.compose.material3.Icon
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.NavigationBarItemDefaults
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.navigation.NavGraph.Companion.findStartDestination
import androidx.navigation.NavHostController
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.currentBackStackEntryAsState
import androidx.navigation.compose.rememberNavController
import com.example.data.model.UserRole
import com.example.ui.screens.AdminDashboardScreen
import com.example.ui.screens.CartScreen
import com.example.ui.screens.HomeScreen
import com.example.ui.screens.OrderHistoryScreen
import com.example.ui.screens.OrderTrackingScreen
import com.example.ui.screens.PaymentScreen
import com.example.ui.screens.ProfileScreen
import com.example.ui.theme.CleanPurplePrimary
import com.example.ui.theme.CleanPurpleContainer
import com.example.ui.theme.CleanSurfaceLight
import com.example.ui.theme.CleanTextSecondaryLight
import com.example.ui.viewmodel.CanteenViewModel

object CanteenRoutes {
    const val HOME = "home"
    const val CART = "cart"
    const val PAYMENT = "payment"
    const val TRACKING = "tracking"
    const val HISTORY = "history"
    const val PROFILE = "profile"
    const val ADMIN = "admin"
}

sealed class BottomNavItem(
    val route: String,
    val title: String,
    val selectedIcon: ImageVector,
    val unselectedIcon: ImageVector
) {
    data object Menu : BottomNavItem(
        route = CanteenRoutes.HOME,
        title = "Menu",
        selectedIcon = Icons.Filled.RestaurantMenu,
        unselectedIcon = Icons.Outlined.RestaurantMenu
    )

    data object Cart : BottomNavItem(
        route = CanteenRoutes.CART,
        title = "Cart",
        selectedIcon = Icons.Filled.ShoppingBag,
        unselectedIcon = Icons.Outlined.ShoppingBag
    )

    data object Tracking : BottomNavItem(
        route = CanteenRoutes.TRACKING,
        title = "Live Token",
        selectedIcon = Icons.Filled.ReceiptLong,
        unselectedIcon = Icons.Filled.ReceiptLong
    )

    data object History : BottomNavItem(
        route = CanteenRoutes.HISTORY,
        title = "Orders",
        selectedIcon = Icons.Filled.History,
        unselectedIcon = Icons.Outlined.History
    )

    data object Profile : BottomNavItem(
        route = CanteenRoutes.PROFILE,
        title = "Profile",
        selectedIcon = Icons.Filled.Person,
        unselectedIcon = Icons.Outlined.Person
    )
}

@Composable
fun CanteenApp(
    viewModel: CanteenViewModel,
    navController: NavHostController = rememberNavController()
) {
    val navBackStackEntry by navController.currentBackStackEntryAsState()
    val currentRoute = navBackStackEntry?.destination?.route

    val cart by viewModel.cart.collectAsStateWithLifecycle()
    val cartCount = cart.sumOf { it.quantity }
    val trackingOrder by viewModel.trackingOrder.collectAsStateWithLifecycle()
    val userRole by viewModel.currentUserRole.collectAsStateWithLifecycle()

    val bottomNavItems = listOf(
        BottomNavItem.Menu,
        BottomNavItem.Cart,
        BottomNavItem.Tracking,
        BottomNavItem.History,
        BottomNavItem.Profile
    )

    val showBottomBar = currentRoute in listOf(
        CanteenRoutes.HOME,
        CanteenRoutes.CART,
        CanteenRoutes.TRACKING,
        CanteenRoutes.HISTORY,
        CanteenRoutes.PROFILE
    )

    Scaffold(
        bottomBar = {
            if (showBottomBar && (userRole == UserRole.CUSTOMER)) {
                NavigationBar(
                    containerColor = CleanSurfaceLight,
                    tonalElevation = 4.dp
                ) {
                    bottomNavItems.forEach { item ->
                        val isSelected = currentRoute == item.route

                        NavigationBarItem(
                            selected = isSelected,
                            onClick = {
                                if (currentRoute != item.route) {
                                    navController.navigate(item.route) {
                                        popUpTo(navController.graph.findStartDestination().id) {
                                            saveState = true
                                        }
                                        launchSingleTop = true
                                        restoreState = true
                                    }
                                }
                            },
                            icon = {
                                BadgedBox(
                                    badge = {
                                        if (item == BottomNavItem.Cart && cartCount > 0) {
                                            Badge(containerColor = CleanPurplePrimary) {
                                                Text("$cartCount", color = Color.White, fontSize = 10.sp)
                                            }
                                        } else if (item == BottomNavItem.Tracking && trackingOrder != null && trackingOrder?.orderStatus in listOf("PLACED", "ACCEPTED", "PREPARING", "READY")) {
                                            Badge(containerColor = if (trackingOrder?.orderStatus == "READY") Color(0xFF16A34A) else CleanPurplePrimary) {
                                                Text("1", color = Color.White, fontSize = 10.sp)
                                            }
                                        }
                                    }
                                ) {
                                    Icon(
                                        imageVector = if (isSelected) item.selectedIcon else item.unselectedIcon,
                                        contentDescription = item.title
                                    )
                                }
                            },
                            label = {
                                Text(
                                    text = item.title,
                                    fontSize = 11.sp,
                                    fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Medium
                                )
                            },
                            colors = NavigationBarItemDefaults.colors(
                                selectedIconColor = CleanPurplePrimary,
                                selectedTextColor = CleanPurplePrimary,
                                unselectedIconColor = CleanTextSecondaryLight,
                                unselectedTextColor = CleanTextSecondaryLight,
                                indicatorColor = CleanPurpleContainer
                            ),
                            modifier = Modifier.testTag("nav_item_${item.route}")
                        )
                    }
                }
            }
        }
    ) { innerPadding ->
        NavHost(
            navController = navController,
            startDestination = CanteenRoutes.HOME,
            modifier = Modifier.padding(innerPadding)
        ) {
            composable(CanteenRoutes.HOME) {
                HomeScreen(
                    viewModel = viewModel,
                    onNavigateToCart = { navController.navigate(CanteenRoutes.CART) },
                    onNavigateToProfile = { navController.navigate(CanteenRoutes.PROFILE) }
                )
            }

            composable(CanteenRoutes.CART) {
                CartScreen(
                    viewModel = viewModel,
                    onBack = { navController.popBackStack() },
                    onProceedToPayment = { navController.navigate(CanteenRoutes.PAYMENT) }
                )
            }

            composable(CanteenRoutes.PAYMENT) {
                PaymentScreen(
                    viewModel = viewModel,
                    onBack = { navController.popBackStack() },
                    onOrderPlaced = { order ->
                        navController.navigate(CanteenRoutes.TRACKING) {
                            popUpTo(CanteenRoutes.HOME)
                        }
                    }
                )
            }

            composable(CanteenRoutes.TRACKING) {
                OrderTrackingScreen(
                    viewModel = viewModel,
                    onBackToHome = {
                        navController.navigate(CanteenRoutes.HOME) {
                            popUpTo(CanteenRoutes.HOME) { inclusive = true }
                        }
                    }
                )
            }

            composable(CanteenRoutes.HISTORY) {
                OrderHistoryScreen(
                    viewModel = viewModel,
                    onBack = { navController.popBackStack() },
                    onTrackOrder = {
                        navController.navigate(CanteenRoutes.TRACKING)
                    },
                    onReorder = {
                        navController.navigate(CanteenRoutes.CART)
                    }
                )
            }

            composable(CanteenRoutes.PROFILE) {
                ProfileScreen(
                    viewModel = viewModel,
                    onBack = { navController.popBackStack() },
                    onSwitchToAdmin = {
                        viewModel.setUserRole(UserRole.STAFF_ADMIN)
                        navController.navigate(CanteenRoutes.ADMIN) {
                            popUpTo(CanteenRoutes.HOME)
                        }
                    }
                )
            }

            composable(CanteenRoutes.ADMIN) {
                AdminDashboardScreen(
                    viewModel = viewModel,
                    onSwitchToCustomer = {
                        viewModel.setUserRole(UserRole.CUSTOMER)
                        navController.navigate(CanteenRoutes.HOME) {
                            popUpTo(CanteenRoutes.HOME) { inclusive = true }
                        }
                    }
                )
            }
        }
    }
}


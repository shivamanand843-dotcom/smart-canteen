package com.example.ui.theme

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

private val DarkColorScheme = darkColorScheme(
    primary = CleanPurpleLight,
    onPrimary = CleanPurpleDark,
    primaryContainer = CleanPurpleDark,
    onPrimaryContainer = CleanPurpleContainer,
    secondary = Color(0xFFCCC2DC),
    onSecondary = Color(0xFF332D41),
    secondaryContainer = Color(0xFF4A4458),
    onSecondaryContainer = Color(0xFFE8DEF8),
    tertiary = Color(0xFFEFB8C8),
    background = DarkBackground,
    surface = DarkSurface,
    surfaceVariant = DarkSurfaceVariant,
    onBackground = TextPrimaryDark,
    onSurface = TextPrimaryDark,
    onSurfaceVariant = TextSecondaryDark,
    outline = CleanBorderSubtle
)

private val LightColorScheme = lightColorScheme(
    primary = CleanPurplePrimary,
    onPrimary = Color.White,
    primaryContainer = CleanPurpleContainer,
    onPrimaryContainer = CleanOnPurpleContainer,
    secondary = Color(0xFF625B71),
    onSecondary = Color.White,
    secondaryContainer = Color(0xFFE8DEF8),
    onSecondaryContainer = Color(0xFF1D192B),
    tertiary = Color(0xFF7D5260),
    background = CleanBackgroundLight,
    surface = CleanBackgroundLight,
    surfaceVariant = CleanSurfaceLight,
    onBackground = CleanTextPrimaryLight,
    onSurface = CleanTextPrimaryLight,
    onSurfaceVariant = CleanTextSecondaryLight,
    outline = CleanBorderSubtle
)

@Composable
fun CanteenTheme(
    darkTheme: Boolean = isSystemInDarkTheme(),
    content: @Composable () -> Unit
) {
    val colorScheme = if (darkTheme) DarkColorScheme else LightColorScheme

    MaterialTheme(
        colorScheme = colorScheme,
        typography = Typography,
        content = content
    )
}

@Composable
fun MyApplicationTheme(
    darkTheme: Boolean = isSystemInDarkTheme(),
    content: @Composable () -> Unit
) {
    CanteenTheme(darkTheme = darkTheme, content = content)
}



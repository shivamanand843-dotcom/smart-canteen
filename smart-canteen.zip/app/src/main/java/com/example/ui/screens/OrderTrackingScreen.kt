package com.example.ui.screens

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.Bolt
import androidx.compose.material.icons.filled.Call
import androidx.compose.material.icons.filled.Celebration
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.ContentCopy
import androidx.compose.material.icons.filled.Fastfood
import androidx.compose.material.icons.filled.NotificationsActive
import androidx.compose.material.icons.filled.RateReview
import androidx.compose.material.icons.filled.Receipt
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Star
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.R
import com.example.data.local.OrderEntity
import com.example.ui.components.OrderTokenBadge
import com.example.ui.components.StatusStepper
import com.example.ui.theme.CleanPurplePrimary
import com.example.ui.theme.CleanPurpleContainer
import com.example.ui.theme.CleanSurfaceLight
import com.example.ui.theme.CleanTextPrimaryLight
import com.example.ui.theme.CleanTextSecondaryLight
import com.example.ui.theme.CleanBorderSubtle
import com.example.ui.theme.SurgeGold
import com.example.ui.theme.VegGreen
import com.example.ui.theme.SurgePillBg
import com.example.ui.theme.SurgePillText
import com.example.ui.viewmodel.CanteenViewModel
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun OrderTrackingScreen(
    viewModel: CanteenViewModel,
    onBackToHome: () -> Unit,
    modifier: Modifier = Modifier
) {
    val trackingOrder by viewModel.trackingOrder.collectAsStateWithLifecycle()
    var showRatingDialog by remember { mutableStateOf(false) }

    Scaffold(
        containerColor = MaterialTheme.colorScheme.background,
        topBar = {
            TopAppBar(
                title = {
                    Text(
                        text = "Live Order Tracking",
                        fontWeight = FontWeight.Bold,
                        style = MaterialTheme.typography.titleMedium,
                        color = CleanTextPrimaryLight
                    )
                },
                navigationIcon = {
                    IconButton(onClick = onBackToHome) {
                        Icon(
                            imageVector = Icons.Default.ArrowBack,
                            contentDescription = "Back",
                            tint = CleanTextPrimaryLight
                        )
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = MaterialTheme.colorScheme.background
                )
            )
        }
    ) { paddingValues ->
        if (trackingOrder == null) {
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(paddingValues)
                    .padding(24.dp),
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.Center
            ) {
                Text(text = "📋", fontSize = 56.sp)
                Spacer(modifier = Modifier.height(14.dp))
                Text(
                    text = "No Active Order to Track",
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.Bold,
                    color = CleanTextPrimaryLight
                )
                Spacer(modifier = Modifier.height(6.dp))
                Text(
                    text = "Place a new canteen order to track live preparation and token status.",
                    fontSize = 13.sp,
                    color = CleanTextSecondaryLight,
                    textAlign = androidx.compose.ui.text.style.TextAlign.Center
                )
                Spacer(modifier = Modifier.height(20.dp))
                Button(
                    onClick = onBackToHome,
                    colors = ButtonDefaults.buttonColors(containerColor = CleanPurplePrimary),
                    shape = RoundedCornerShape(20.dp)
                ) {
                    Text("Go to Canteen Menu", color = Color.White, fontWeight = FontWeight.Bold)
                }
            }
        } else {
            val order = trackingOrder!!
            val isPriority = order.orderType == "PRIORITY"
            val isReady = order.orderStatus == "READY"
            val isPickedUp = order.orderStatus == "PICKED_UP"

            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(paddingValues)
                    .padding(horizontal = 16.dp)
                    .verticalScroll(rememberScrollState()),
                verticalArrangement = Arrangement.spacedBy(14.dp)
            ) {
                // READY CELEBRATION BANNER
                AnimatedVisibility(visible = isReady) {
                    Card(
                        modifier = Modifier.fillMaxWidth(),
                        colors = CardDefaults.cardColors(containerColor = Color(0xFFE8F5E9)),
                        shape = RoundedCornerShape(20.dp),
                        border = androidx.compose.foundation.BorderStroke(1.dp, VegGreen.copy(alpha = 0.5f))
                    ) {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(16.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Box(
                                modifier = Modifier
                                    .size(52.dp)
                                    .clip(RoundedCornerShape(14.dp))
                                    .background(VegGreen),
                                contentAlignment = Alignment.Center
                            ) {
                                Image(
                                    painter = painterResource(id = R.drawable.img_order_ready),
                                    contentDescription = "Ready",
                                    modifier = Modifier.size(40.dp)
                                )
                            }

                            Spacer(modifier = Modifier.width(12.dp))

                            Column(modifier = Modifier.weight(1f)) {
                                Text(
                                    text = "🔔 YOUR ORDER IS READY!",
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 15.sp,
                                    color = Color(0xFF14532D)
                                )
                                Text(
                                    text = "Please collect Token #${order.tokenNumber} at Counter #${order.counterNumber}.",
                                    fontSize = 12.sp,
                                    color = Color(0xFF166534)
                                )
                            }
                        }
                    }
                }

                // Digital Token Card
                OrderTokenBadge(order = order)

                // Live Status Progress Stepper
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    colors = CardDefaults.cardColors(containerColor = CleanSurfaceLight),
                    shape = RoundedCornerShape(20.dp),
                    border = androidx.compose.foundation.BorderStroke(1.dp, CleanBorderSubtle.copy(alpha = 0.5f)),
                    elevation = CardDefaults.cardElevation(defaultElevation = 0.dp)
                ) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                text = "Live Order Status",
                                style = MaterialTheme.typography.titleSmall,
                                fontWeight = FontWeight.Bold,
                                color = CleanTextPrimaryLight
                            )
                            Surface(
                                color = when (order.orderStatus) {
                                    "READY" -> Color(0xFFE8F5E9)
                                    "PREPARING" -> CleanPurpleContainer
                                    "PICKED_UP" -> Color(0xFFE2E8F0)
                                    else -> CleanPurpleContainer.copy(alpha = 0.6f)
                                },
                                shape = RoundedCornerShape(6.dp)
                            ) {
                                Text(
                                    text = order.orderStatus,
                                    fontSize = 11.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = when (order.orderStatus) {
                                        "READY" -> VegGreen
                                        "PREPARING" -> CleanPurplePrimary
                                        "PICKED_UP" -> CleanTextSecondaryLight
                                        else -> CleanPurplePrimary
                                    },
                                    modifier = Modifier.padding(horizontal = 8.dp, vertical = 3.dp)
                                )
                            }
                        }

                        Spacer(modifier = Modifier.height(16.dp))

                        StatusStepper(currentStatus = order.orderStatus)

                        Spacer(modifier = Modifier.height(14.dp))

                        val statusExplanation = when (order.orderStatus) {
                            "PLACED" -> "Order received by POS system. Waiting for kitchen acceptance."
                            "ACCEPTED" -> "Kitchen accepted order! Preparing ingredients for fast cooking."
                            "PREPARING" -> if (isPriority) "Chef is actively preparing your order in the Express Priority Lane."
                            else "Cooking in progress on main kitchen griddle."
                            "READY" -> "Ready on pickup tray at Counter #${order.counterNumber}! Please show your token."
                            "PICKED_UP" -> "Order successfully completed. Enjoy your meal!"
                            else -> "In process"
                        }

                        Text(
                            text = statusExplanation,
                            fontSize = 12.sp,
                            color = CleanTextSecondaryLight
                        )
                    }
                }

                // Estimated Ready Time Card
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    colors = CardDefaults.cardColors(
                        containerColor = if (isPriority) CleanPurpleContainer.copy(alpha = 0.35f) else CleanSurfaceLight
                    ),
                    shape = RoundedCornerShape(20.dp),
                    border = androidx.compose.foundation.BorderStroke(
                        1.dp,
                        if (isPriority) CleanPurplePrimary.copy(alpha = 0.3f) else CleanBorderSubtle.copy(alpha = 0.5f)
                    ),
                    elevation = CardDefaults.cardElevation(defaultElevation = 0.dp)
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(16.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Column {
                            Text(
                                text = "ESTIMATED READY TIME",
                                fontSize = 10.sp,
                                fontWeight = FontWeight.Bold,
                                color = CleanTextSecondaryLight
                            )
                            Text(
                                text = SimpleDateFormat("hh:mm a", Locale.US).format(Date(order.estimatedReadyTime)),
                                style = MaterialTheme.typography.titleMedium,
                                fontWeight = FontWeight.Bold,
                                color = if (isPriority) CleanPurplePrimary else CleanTextPrimaryLight
                            )
                        }

                        if (isPriority) {
                            Surface(
                                color = SurgePillBg,
                                shape = RoundedCornerShape(6.dp)
                            ) {
                                Row(
                                    modifier = Modifier.padding(horizontal = 8.dp, vertical = 3.dp),
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Icon(
                                        imageVector = Icons.Default.Bolt,
                                        contentDescription = null,
                                        tint = SurgePillText,
                                        modifier = Modifier.size(12.dp)
                                    )
                                    Spacer(modifier = Modifier.width(3.dp))
                                    Text(
                                        text = "Priority Surge Applied",
                                        color = SurgePillText,
                                        fontSize = 11.sp,
                                        fontWeight = FontWeight.Bold
                                    )
                                }
                            }
                        }
                    }
                }

                // Ordered Items Summary
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    colors = CardDefaults.cardColors(containerColor = CleanSurfaceLight),
                    shape = RoundedCornerShape(20.dp),
                    border = androidx.compose.foundation.BorderStroke(1.dp, CleanBorderSubtle.copy(alpha = 0.5f)),
                    elevation = CardDefaults.cardElevation(defaultElevation = 0.dp)
                ) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Text(
                            text = "Order Receipt",
                            style = MaterialTheme.typography.titleSmall,
                            fontWeight = FontWeight.Bold,
                            color = CleanTextPrimaryLight
                        )
                        Spacer(modifier = Modifier.height(10.dp))

                        val itemList = order.itemsJson.split(";")
                        itemList.forEach { itemLine ->
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(vertical = 4.dp),
                                horizontalArrangement = Arrangement.SpaceBetween
                            ) {
                                Text(
                                    text = "• $itemLine",
                                    fontSize = 13.sp,
                                    color = CleanTextPrimaryLight,
                                    fontWeight = FontWeight.Medium
                                )
                            }
                        }

                        Spacer(modifier = Modifier.height(10.dp))
                        HorizontalDivider(color = CleanBorderSubtle.copy(alpha = 0.4f))
                        Spacer(modifier = Modifier.height(10.dp))

                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Text("Items Base Total", fontSize = 12.sp, color = CleanTextSecondaryLight)
                            Text("₹${order.baseAmount.toInt()}", fontSize = 12.sp, fontWeight = FontWeight.SemiBold, color = CleanTextPrimaryLight)
                        }

                        if (order.priorityFee > 0) {
                            Spacer(modifier = Modifier.height(4.dp))
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween
                            ) {
                                Text("Priority Rush Fee", fontSize = 12.sp, color = CleanPurplePrimary, fontWeight = FontWeight.Bold)
                                Text("+₹${order.priorityFee.toInt()}", fontSize = 12.sp, color = CleanPurplePrimary, fontWeight = FontWeight.Bold)
                            }
                        }

                        Spacer(modifier = Modifier.height(4.dp))
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Text("Packaging & Convenience", fontSize = 12.sp, color = CleanTextSecondaryLight)
                            Text("₹${order.taxesAndFees.toInt()}", fontSize = 12.sp, fontWeight = FontWeight.SemiBold, color = CleanTextPrimaryLight)
                        }

                        Spacer(modifier = Modifier.height(8.dp))
                        HorizontalDivider(color = CleanBorderSubtle.copy(alpha = 0.4f))
                        Spacer(modifier = Modifier.height(8.dp))

                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Text("Total Paid (${order.paymentMethod})", fontWeight = FontWeight.Bold, fontSize = 14.sp, color = CleanTextPrimaryLight)
                            Text("₹${order.totalAmount.toInt()}", fontWeight = FontWeight.Bold, fontSize = 15.sp, color = CleanPurplePrimary)
                        }
                    }
                }

                // Rate & Review CTA
                if (order.rating > 0) {
                    Card(
                        modifier = Modifier.fillMaxWidth(),
                        colors = CardDefaults.cardColors(containerColor = CleanPurpleContainer.copy(alpha = 0.3f)),
                        shape = RoundedCornerShape(16.dp),
                        border = androidx.compose.foundation.BorderStroke(1.dp, CleanBorderSubtle.copy(alpha = 0.4f))
                    ) {
                        Row(
                            modifier = Modifier.padding(12.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Icon(imageVector = Icons.Default.Star, contentDescription = null, tint = SurgeGold)
                            Spacer(modifier = Modifier.width(8.dp))
                            Column {
                                Text(text = "Your Rating: ${order.rating.toInt()} / 5 Stars", fontWeight = FontWeight.Bold, fontSize = 13.sp, color = CleanTextPrimaryLight)
                                if (order.reviewComment.isNotBlank()) {
                                    Text(text = "\"${order.reviewComment}\"", fontSize = 12.sp, color = CleanTextSecondaryLight)
                                }
                            }
                        }
                    }
                } else if (isReady || isPickedUp) {
                    OutlinedButton(
                        onClick = { showRatingDialog = true },
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(16.dp),
                        border = androidx.compose.foundation.BorderStroke(1.dp, CleanPurplePrimary)
                    ) {
                        Icon(imageVector = Icons.Default.RateReview, contentDescription = null, tint = CleanPurplePrimary)
                        Spacer(modifier = Modifier.width(6.dp))
                        Text("Rate Food & Queue Experience", color = CleanPurplePrimary, fontWeight = FontWeight.Bold)
                    }
                }

                Spacer(modifier = Modifier.height(16.dp))
            }

            // Rating Dialog
            if (showRatingDialog) {
                var selectedStars by remember { mutableFloatStateOf(5f) }
                var reviewText by remember { mutableStateOf("") }

                AlertDialog(
                    onDismissRequest = { showRatingDialog = false },
                    title = { Text("Rate Canteen Service", fontWeight = FontWeight.Bold, color = CleanTextPrimaryLight) },
                    text = {
                        Column {
                            Text("How was your pickup speed and food quality?", color = CleanTextSecondaryLight)
                            Spacer(modifier = Modifier.height(12.dp))
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.Center
                            ) {
                                (1..5).forEach { star ->
                                    IconButton(onClick = { selectedStars = star.toFloat() }) {
                                        Icon(
                                            imageVector = Icons.Default.Star,
                                            contentDescription = "$star stars",
                                            tint = if (star <= selectedStars) SurgeGold else CleanBorderSubtle,
                                            modifier = Modifier.size(32.dp)
                                        )
                                    }
                                }
                            }
                            Spacer(modifier = Modifier.height(8.dp))
                            OutlinedTextField(
                                value = reviewText,
                                onValueChange = { reviewText = it },
                                placeholder = { Text("Share quick feedback on speed or taste...") },
                                modifier = Modifier.fillMaxWidth(),
                                maxLines = 3,
                                shape = RoundedCornerShape(12.dp)
                            )
                        }
                    },
                    confirmButton = {
                        Button(
                            onClick = {
                                viewModel.rateOrder(order.orderId, selectedStars, reviewText)
                                showRatingDialog = false
                            },
                            colors = ButtonDefaults.buttonColors(containerColor = CleanPurplePrimary),
                            shape = RoundedCornerShape(12.dp)
                        ) {
                            Text("Submit Feedback", color = Color.White)
                        }
                    },
                    dismissButton = {
                        TextButton(onClick = { showRatingDialog = false }) {
                            Text("Cancel", color = CleanTextSecondaryLight)
                        }
                    }
                )
            }
        }
    }
}


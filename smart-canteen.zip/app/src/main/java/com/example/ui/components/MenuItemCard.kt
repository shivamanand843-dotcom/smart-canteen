package com.example.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Star
import androidx.compose.material.icons.filled.Timer
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.local.MenuItemEntity
import com.example.ui.theme.CleanPurpleContainer
import com.example.ui.theme.CleanPurplePrimary
import com.example.ui.theme.CleanSurfaceLight
import com.example.ui.theme.CleanTextPrimaryLight
import com.example.ui.theme.CleanTextSecondaryLight
import com.example.ui.theme.NonVegRed
import com.example.ui.theme.VegGreen
import com.example.ui.theme.VeganPurple

@Composable
fun MenuItemCard(
    item: MenuItemEntity,
    onClick: () -> Unit,
    onAddClick: () -> Unit,
    modifier: Modifier = Modifier,
    cartQuantity: Int = 0
) {
    val isSoldOut = !item.isAvailable || item.stockQuantity <= 0

    Card(
        modifier = modifier
            .fillMaxWidth()
            .testTag("menu_item_${item.id}")
            .clip(RoundedCornerShape(24.dp))
            .clickable(enabled = !isSoldOut, onClick = onClick),
        colors = CardDefaults.cardColors(
            containerColor = CleanSurfaceLight
        ),
        elevation = CardDefaults.cardElevation(defaultElevation = 0.dp)
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(14.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            // Food Icon Avatar Box with Clean Lavender background
            Box(
                modifier = Modifier
                    .size(64.dp)
                    .clip(RoundedCornerShape(18.dp))
                    .background(
                        if (isSoldOut) Color(0xFFE2E8F0)
                        else Color(0xFFD1C4E9)
                    ),
                contentAlignment = Alignment.Center
            ) {
                Text(
                    text = item.iconEmoji,
                    fontSize = 28.sp
                )

                if (item.isPopularRushItem) {
                    Box(
                        modifier = Modifier
                            .align(Alignment.TopStart)
                            .background(
                                color = Color(0xFF21005D),
                                shape = RoundedCornerShape(bottomEnd = 8.dp)
                            )
                            .padding(horizontal = 4.dp, vertical = 2.dp)
                    ) {
                        Text(
                            text = "RUSH",
                            color = Color(0xFFD0BCFF),
                            fontSize = 8.sp,
                            fontWeight = FontWeight.Bold
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.width(14.dp))

            // Details Column
            Column(
                modifier = Modifier.weight(1f)
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    DietaryBadge(dietaryType = item.dietaryType)

                    Spacer(modifier = Modifier.width(6.dp))

                    Text(
                        text = item.name,
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.SemiBold,
                        fontSize = 15.sp,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis,
                        color = if (isSoldOut) Color(0xFF94A3B8) else CleanTextPrimaryLight
                    )
                }

                Spacer(modifier = Modifier.height(2.dp))

                Text(
                    text = item.description,
                    style = MaterialTheme.typography.bodySmall,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis,
                    fontSize = 12.sp,
                    color = CleanTextSecondaryLight
                )

                Spacer(modifier = Modifier.height(6.dp))

                // Info row: Prep time & rating
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(
                            imageVector = Icons.Default.Timer,
                            contentDescription = null,
                            tint = CleanTextSecondaryLight,
                            modifier = Modifier.size(12.dp)
                        )
                        Spacer(modifier = Modifier.width(2.dp))
                        Text(
                            text = "${item.prepTimeMinutes}m",
                            fontSize = 11.sp,
                            color = CleanTextSecondaryLight
                        )
                    }

                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(
                            imageVector = Icons.Default.Star,
                            contentDescription = null,
                            tint = Color(0xFFEAA000),
                            modifier = Modifier.size(12.dp)
                        )
                        Spacer(modifier = Modifier.width(2.dp))
                        Text(
                            text = "${item.rating}",
                            fontSize = 11.sp,
                            fontWeight = FontWeight.SemiBold,
                            color = CleanTextSecondaryLight
                        )
                    }

                    if (item.stockQuantity in 1..10 && !isSoldOut) {
                        Text(
                            text = "${item.stockQuantity} left",
                            fontSize = 10.sp,
                            fontWeight = FontWeight.Bold,
                            color = Color(0xFFB3261E)
                        )
                    }
                }

                Spacer(modifier = Modifier.height(6.dp))

                // Price and Add Button
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Text(
                        text = "₹${item.price.toInt()}",
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold,
                        fontSize = 15.sp,
                        color = CleanTextPrimaryLight
                    )

                    if (isSoldOut) {
                        Surface(
                            color = Color(0xFFE7E0EC),
                            shape = RoundedCornerShape(12.dp)
                        ) {
                            Text(
                                text = "SOLD OUT",
                                color = Color(0xFF79747E),
                                fontSize = 10.sp,
                                fontWeight = FontWeight.Bold,
                                modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                            )
                        }
                    } else {
                        Surface(
                            modifier = Modifier
                                .testTag("add_button_${item.id}")
                                .clip(RoundedCornerShape(16.dp))
                                .clickable(onClick = onAddClick),
                            color = if (cartQuantity > 0) CleanPurplePrimary else CleanPurpleContainer,
                            shape = RoundedCornerShape(16.dp)
                        ) {
                            Row(
                                modifier = Modifier.padding(horizontal = 10.dp, vertical = 4.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                if (cartQuantity > 0) {
                                    Text(
                                        text = "$cartQuantity added",
                                        color = Color.White,
                                        fontSize = 11.sp,
                                        fontWeight = FontWeight.Bold
                                    )
                                } else {
                                    Icon(
                                        imageVector = Icons.Default.Add,
                                        contentDescription = "Add item",
                                        tint = CleanPurplePrimary,
                                        modifier = Modifier.size(13.dp)
                                    )
                                    Spacer(modifier = Modifier.width(2.dp))
                                    Text(
                                        text = "ADD",
                                        color = CleanPurplePrimary,
                                        fontSize = 11.sp,
                                        fontWeight = FontWeight.Bold
                                    )
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun DietaryBadge(dietaryType: String, modifier: Modifier = Modifier) {
    val (borderColor, dotColor) = when (dietaryType.uppercase()) {
        "VEG" -> Pair(VegGreen, VegGreen)
        "NON_VEG" -> Pair(NonVegRed, NonVegRed)
        "VEGAN" -> Pair(VeganPurple, VeganPurple)
        "BEVERAGE" -> Pair(CleanPurplePrimary, CleanPurplePrimary)
        else -> Pair(Color(0xFF64748B), Color(0xFF64748B))
    }

    Box(
        modifier = modifier
            .size(14.dp)
            .border(1.dp, borderColor, RoundedCornerShape(3.dp)),
        contentAlignment = Alignment.Center
    ) {
        Box(
            modifier = Modifier
                .size(6.dp)
                .background(dotColor, CircleShape)
        )
    }
}


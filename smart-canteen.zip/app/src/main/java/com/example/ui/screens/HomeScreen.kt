package com.example.ui.screens

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.slideInVertically
import androidx.compose.animation.slideOutVertically
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AccountBalanceWallet
import androidx.compose.material.icons.filled.Clear
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.ShoppingBag
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.R
import com.example.data.model.DietaryType
import com.example.ui.components.MenuItemCard
import com.example.ui.components.SurgeBannerCard
import com.example.ui.theme.CleanPurplePrimary
import com.example.ui.theme.CleanPurpleContainer
import com.example.ui.theme.CleanOnPurpleContainer
import com.example.ui.theme.CleanSurfaceLight
import com.example.ui.theme.CleanTextPrimaryLight
import com.example.ui.theme.CleanTextSecondaryLight
import com.example.ui.theme.CleanBorderSubtle
import com.example.ui.theme.VegGreen
import com.example.ui.viewmodel.CanteenViewModel

@Composable
fun HomeScreen(
    viewModel: CanteenViewModel,
    onNavigateToCart: () -> Unit,
    onNavigateToProfile: () -> Unit,
    modifier: Modifier = Modifier
) {
    val menuItems by viewModel.filteredMenuItems.collectAsStateWithLifecycle()
    val surgeCalculation by viewModel.surgeCalculation.collectAsStateWithLifecycle()
    val searchQuery by viewModel.searchQuery.collectAsStateWithLifecycle()
    val selectedCategory by viewModel.selectedCategory.collectAsStateWithLifecycle()
    val selectedDietaryFilter by viewModel.selectedDietaryFilter.collectAsStateWithLifecycle()
    val inStockOnly by viewModel.inStockOnly.collectAsStateWithLifecycle()
    val cart by viewModel.cart.collectAsStateWithLifecycle()
    val user by viewModel.currentUser.collectAsStateWithLifecycle()
    val detailItem by viewModel.detailItem.collectAsStateWithLifecycle()

    val categories = listOf(
        "All",
        "Popular Rush",
        "Meals & Thalis",
        "Fast Food & Snacks",
        "Beverages",
        "Desserts",
        "Stationery"
    )

    val cartTotalCount = cart.sumOf { it.quantity }
    val cartTotalPrice = cart.sumOf { it.totalPrice }

    Box(modifier = modifier.fillMaxSize()) {
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .testTag("home_menu_list"),
            contentPadding = PaddingValues(
                start = 16.dp,
                end = 16.dp,
                top = 12.dp,
                bottom = if (cartTotalCount > 0) 96.dp else 24.dp
            ),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            // Header: Canteen location + User Wallet Pill
            item {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column {
                        Text(
                            text = "Campus Canteen",
                            fontSize = 22.sp,
                            fontWeight = FontWeight.Bold,
                            color = CleanTextPrimaryLight
                        )
                        Text(
                            text = "Food Court Block-B • Open till 10 PM",
                            fontSize = 12.sp,
                            color = CleanTextSecondaryLight
                        )
                    }

                    // Wallet Balance Badge
                    Surface(
                        modifier = Modifier
                            .clip(RoundedCornerShape(20.dp))
                            .clickable(onClick = onNavigateToProfile)
                            .testTag("wallet_balance_pill"),
                        color = CleanSurfaceLight,
                        border = androidx.compose.foundation.BorderStroke(1.dp, CleanBorderSubtle.copy(alpha = 0.5f))
                    ) {
                        Row(
                            modifier = Modifier.padding(horizontal = 12.dp, vertical = 6.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Icon(
                                imageVector = Icons.Default.AccountBalanceWallet,
                                contentDescription = "Wallet",
                                tint = CleanPurplePrimary,
                                modifier = Modifier.size(16.dp)
                            )
                            Spacer(modifier = Modifier.width(6.dp))
                            Text(
                                text = "₹${user.walletBalance.toInt()}",
                                fontSize = 13.sp,
                                fontWeight = FontWeight.Bold,
                                color = CleanTextPrimaryLight
                            )
                        }
                    }
                }
            }

            // Dynamic Surge Priority Banner
            item {
                SurgeBannerCard(
                    surge = surgeCalculation,
                    onSimulateClick = { viewModel.simulateIncomingRushOrder() }
                )
            }

            // Search Bar
            item {
                OutlinedTextField(
                    value = searchQuery,
                    onValueChange = { viewModel.setSearchQuery(it) },
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("search_food_input"),
                    placeholder = { Text("Search ramen, paneer, lassi, snacks...", color = CleanTextSecondaryLight, fontSize = 14.sp) },
                    leadingIcon = {
                        Icon(imageVector = Icons.Default.Search, contentDescription = "Search", tint = CleanTextSecondaryLight)
                    },
                    trailingIcon = {
                        if (searchQuery.isNotBlank()) {
                            IconButton(onClick = { viewModel.setSearchQuery("") }) {
                                Icon(imageVector = Icons.Default.Clear, contentDescription = "Clear search", tint = CleanTextSecondaryLight)
                            }
                        }
                    },
                    singleLine = true,
                    shape = RoundedCornerShape(24.dp),
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedBorderColor = CleanPurplePrimary,
                        unfocusedBorderColor = CleanBorderSubtle.copy(alpha = 0.6f),
                        focusedContainerColor = CleanSurfaceLight,
                        unfocusedContainerColor = CleanSurfaceLight
                    )
                )
            }

            // Category Chips Row
            item {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .horizontalScroll(rememberScrollState()),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    categories.forEach { category ->
                        val isSelected = selectedCategory == category
                        FilterChip(
                            selected = isSelected,
                            onClick = { viewModel.setSelectedCategory(category) },
                            label = {
                                Text(
                                    text = category,
                                    fontSize = 13.sp,
                                    fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal
                                )
                            },
                            colors = FilterChipDefaults.filterChipColors(
                                selectedContainerColor = CleanPurpleContainer,
                                selectedLabelColor = CleanOnPurpleContainer,
                                containerColor = CleanSurfaceLight,
                                labelColor = CleanTextSecondaryLight
                            ),
                            border = FilterChipDefaults.filterChipBorder(
                                enabled = true,
                                selected = isSelected,
                                borderColor = if (isSelected) CleanPurplePrimary else CleanBorderSubtle.copy(alpha = 0.4f)
                            ),
                            shape = RoundedCornerShape(20.dp),
                            modifier = Modifier.testTag("category_chip_$category")
                        )
                    }
                }
            }

            // Dietary and In-Stock Quick Filters
            item {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    FilterChip(
                        selected = selectedDietaryFilter == DietaryType.VEG,
                        onClick = {
                            viewModel.setDietaryFilter(if (selectedDietaryFilter == DietaryType.VEG) null else DietaryType.VEG)
                        },
                        label = { Text("🌱 Veg Only", fontSize = 12.sp) },
                        colors = FilterChipDefaults.filterChipColors(
                            selectedContainerColor = Color(0xFFDCFCE7),
                            selectedLabelColor = VegGreen,
                            containerColor = CleanSurfaceLight,
                            labelColor = CleanTextSecondaryLight
                        ),
                        shape = RoundedCornerShape(16.dp)
                    )

                    FilterChip(
                        selected = selectedDietaryFilter == DietaryType.NON_VEG,
                        onClick = {
                            viewModel.setDietaryFilter(if (selectedDietaryFilter == DietaryType.NON_VEG) null else DietaryType.NON_VEG)
                        },
                        label = { Text("🍗 Non-Veg", fontSize = 12.sp) },
                        colors = FilterChipDefaults.filterChipColors(
                            selectedContainerColor = Color(0xFFFEE2E2),
                            selectedLabelColor = Color(0xFFDC2626),
                            containerColor = CleanSurfaceLight,
                            labelColor = CleanTextSecondaryLight
                        ),
                        shape = RoundedCornerShape(16.dp)
                    )

                    FilterChip(
                        selected = inStockOnly,
                        onClick = { viewModel.toggleInStockOnly() },
                        label = { Text("In Stock", fontSize = 12.sp) },
                        colors = FilterChipDefaults.filterChipColors(
                            selectedContainerColor = CleanPurpleContainer,
                            selectedLabelColor = CleanOnPurpleContainer,
                            containerColor = CleanSurfaceLight,
                            labelColor = CleanTextSecondaryLight
                        ),
                        shape = RoundedCornerShape(16.dp)
                    )
                }
            }

            // Section Title with Items Count
            item {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = if (selectedCategory == "All") "Menu" else selectedCategory,
                        fontSize = 15.sp,
                        fontWeight = FontWeight.Bold,
                        color = CleanTextPrimaryLight
                    )
                    Text(
                        text = "${menuItems.size} items",
                        fontSize = 12.sp,
                        color = CleanTextSecondaryLight
                    )
                }
            }

            // Menu Items List
            if (menuItems.isEmpty()) {
                item {
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(vertical = 36.dp),
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        Text(text = "🍽️", fontSize = 48.sp)
                        Spacer(modifier = Modifier.height(10.dp))
                        Text(
                            text = "No items matched your search",
                            style = MaterialTheme.typography.titleSmall,
                            fontWeight = FontWeight.Bold
                        )
                        Text(
                            text = "Try clearing filters or search for other items.",
                            fontSize = 12.sp,
                            color = CleanTextSecondaryLight
                        )
                    }
                }
            } else {
                items(menuItems, key = { it.id }) { item ->
                    val cartQty = cart.find { it.menuItem.id == item.id }?.quantity ?: 0
                    MenuItemCard(
                        item = item,
                        cartQuantity = cartQty,
                        onClick = { viewModel.openItemDetail(item) },
                        onAddClick = {
                            if (item.addOnsJson.isNotBlank()) {
                                viewModel.openItemDetail(item)
                            } else {
                                viewModel.addToCart(item, 1)
                            }
                        }
                    )
                }
            }
        }

        // Bottom Cart Summary Bar
        AnimatedVisibility(
            visible = cartTotalCount > 0,
            enter = slideInVertically(initialOffsetY = { it }),
            exit = slideOutVertically(targetOffsetY = { it }),
            modifier = Modifier.align(Alignment.BottomCenter)
        ) {
            Surface(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(16.dp)
                    .testTag("floating_cart_bar"),
                shape = RoundedCornerShape(28.dp),
                color = CleanPurplePrimary,
                shadowElevation = 6.dp
            ) {
                Row(
                    modifier = Modifier
                        .clickable(onClick = onNavigateToCart)
                        .padding(horizontal = 20.dp, vertical = 14.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Box(
                            modifier = Modifier
                                .size(36.dp)
                                .background(Color.White.copy(alpha = 0.2f), CircleShape),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(
                                imageVector = Icons.Default.ShoppingBag,
                                contentDescription = "Cart",
                                tint = Color.White,
                                modifier = Modifier.size(18.dp)
                            )
                        }
                        Spacer(modifier = Modifier.width(12.dp))
                        Column {
                            Text(
                                text = "$cartTotalCount ${if (cartTotalCount == 1) "item" else "items"} • ₹${cartTotalPrice.toInt()}",
                                color = Color.White,
                                style = MaterialTheme.typography.titleSmall,
                                fontWeight = FontWeight.Bold
                            )
                            Text(
                                text = "Review order & choose lane",
                                color = Color(0xFFEADDFF),
                                fontSize = 11.sp
                            )
                        }
                    }

                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text(
                            text = "Review",
                            color = Color.White,
                            fontWeight = FontWeight.Bold,
                            fontSize = 14.sp
                        )
                        Spacer(modifier = Modifier.width(4.dp))
                        Text(text = "➔", color = Color.White, fontSize = 14.sp)
                    }
                }
            }
        }

        // Item Detail Bottom Sheet
        detailItem?.let { item ->
            ItemDetailBottomSheet(
                item = item,
                onDismiss = { viewModel.closeItemDetail() },
                onAddToCart = { mItem, qty, addOns, notes ->
                    viewModel.addToCart(mItem, qty, addOns, notes)
                }
            )
        }
    }
}


package com.example.ui.components

import androidx.compose.animation.animateColorAsState
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.DoneAll
import androidx.compose.material.icons.filled.OutdoorGrill
import androidx.compose.material.icons.filled.ReceiptLong
import androidx.compose.material.icons.filled.Restaurant
import androidx.compose.material.icons.filled.TakeoutDining
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.OrderStatus
import com.example.ui.theme.CleanBorderSubtle
import com.example.ui.theme.CleanPurplePrimary
import com.example.ui.theme.CleanTextPrimaryLight
import com.example.ui.theme.CleanTextSecondaryLight
import com.example.ui.theme.VegGreen

@Composable
fun StatusStepper(
    currentStatus: String,
    modifier: Modifier = Modifier
) {
    val steps = listOf(
        StepData("Placed", OrderStatus.PLACED, Icons.Default.ReceiptLong),
        StepData("Accepted", OrderStatus.ACCEPTED, Icons.Default.Restaurant),
        StepData("Preparing", OrderStatus.PREPARING, Icons.Default.OutdoorGrill),
        StepData("Ready", OrderStatus.READY, Icons.Default.TakeoutDining),
        StepData("Picked Up", OrderStatus.PICKED_UP, Icons.Default.DoneAll)
    )

    val currentStepIndex = when (currentStatus.uppercase()) {
        "PLACED" -> 0
        "ACCEPTED" -> 1
        "PREPARING" -> 2
        "READY" -> 3
        "PICKED_UP" -> 4
        else -> 0
    }

    Column(modifier = modifier.fillMaxWidth()) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            steps.forEachIndexed { index, step ->
                val isCompleted = index < currentStepIndex
                val isCurrent = index == currentStepIndex
                val isPending = index > currentStepIndex

                val circleBg by animateColorAsState(
                    targetValue = when {
                        isCompleted -> CleanPurplePrimary
                        isCurrent -> CleanPurplePrimary
                        else -> CleanBorderSubtle.copy(alpha = 0.5f)
                    },
                    label = "circleBg"
                )

                val iconTint = if (isPending) CleanTextSecondaryLight else Color.White

                Column(
                    horizontalAlignment = Alignment.CenterHorizontally,
                    modifier = Modifier.weight(1f)
                ) {
                    Box(
                        modifier = Modifier
                            .size(32.dp)
                            .clip(CircleShape)
                            .background(circleBg),
                        contentAlignment = Alignment.Center
                    ) {
                        if (isCompleted) {
                            Icon(
                                imageVector = Icons.Default.Check,
                                contentDescription = null,
                                tint = Color.White,
                                modifier = Modifier.size(18.dp)
                            )
                        } else {
                            Icon(
                                imageVector = step.icon,
                                contentDescription = null,
                                tint = iconTint,
                                modifier = Modifier.size(16.dp)
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(4.dp))

                    Text(
                        text = step.label,
                        fontSize = 10.sp,
                        fontWeight = if (isCurrent) FontWeight.Bold else FontWeight.Normal,
                        color = if (isCurrent) CleanPurplePrimary else if (isCompleted) CleanTextPrimaryLight else CleanTextSecondaryLight
                    )
                }

                // Connecting Line between steps
                if (index < steps.size - 1) {
                    val lineBg by animateColorAsState(
                        targetValue = if (index < currentStepIndex) CleanPurplePrimary else CleanBorderSubtle.copy(alpha = 0.5f),
                        label = "lineBg"
                    )
                    Box(
                        modifier = Modifier
                            .height(2.dp)
                            .weight(0.7f)
                            .background(lineBg)
                    )
                }
            }
        }
    }
}

private data class StepData(
    val label: String,
    val status: OrderStatus,
    val icon: ImageVector
)

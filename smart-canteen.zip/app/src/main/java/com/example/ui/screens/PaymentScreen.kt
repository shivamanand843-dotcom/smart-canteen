package com.example.ui.screens

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AccountBalanceWallet
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.Bolt
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.CreditCard
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.Payments
import androidx.compose.material.icons.filled.QrCode
import androidx.compose.material.icons.filled.Storefront
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.RadioButton
import androidx.compose.material3.RadioButtonDefaults
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.data.local.OrderEntity
import com.example.data.model.OrderType
import com.example.data.model.PaymentMethod
import com.example.ui.theme.CleanPurplePrimary
import com.example.ui.theme.CleanPurpleContainer
import com.example.ui.theme.CleanSurfaceLight
import com.example.ui.theme.CleanTextPrimaryLight
import com.example.ui.theme.CleanTextSecondaryLight
import com.example.ui.theme.CleanBorderSubtle
import com.example.ui.theme.PriorityDarkCard
import com.example.ui.theme.SurgeHighlightText
import com.example.ui.viewmodel.CanteenViewModel
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun PaymentScreen(
    viewModel: CanteenViewModel,
    onBack: () -> Unit,
    onOrderPlaced: (OrderEntity) -> Unit,
    modifier: Modifier = Modifier
) {
    val cart by viewModel.cart.collectAsStateWithLifecycle()
    val selectedOrderType by viewModel.selectedOrderType.collectAsStateWithLifecycle()
    val surge by viewModel.surgeCalculation.collectAsStateWithLifecycle()
    val user by viewModel.currentUser.collectAsStateWithLifecycle()

    val itemTotal = cart.sumOf { it.totalPrice }
    val packagingFee = if (cart.isNotEmpty()) 10.0 else 0.0
    val priorityFee = if (selectedOrderType == OrderType.PRIORITY) surge.totalPriorityFee else 0.0
    val grandTotal = itemTotal + packagingFee + priorityFee

    var selectedMethod by remember { mutableStateOf(PaymentMethod.CAMPUS_WALLET) }
    var isProcessing by remember { mutableStateOf(false) }
    val scope = rememberCoroutineScope()

    Scaffold(
        containerColor = MaterialTheme.colorScheme.background,
        topBar = {
            TopAppBar(
                title = {
                    Text(
                        text = "Checkout & Payment",
                        fontWeight = FontWeight.Bold,
                        fontSize = 18.sp,
                        color = CleanTextPrimaryLight
                    )
                },
                navigationIcon = {
                    IconButton(onClick = onBack) {
                        Icon(imageVector = Icons.Default.ArrowBack, contentDescription = "Back", tint = CleanTextPrimaryLight)
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = MaterialTheme.colorScheme.background
                )
            )
        },
        bottomBar = {
            Surface(
                color = CleanSurfaceLight,
                shadowElevation = 8.dp,
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(16.dp)
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column {
                            Text(
                                text = "Grand Total",
                                fontSize = 12.sp,
                                color = CleanTextSecondaryLight
                            )
                            Text(
                                text = "₹${grandTotal.toInt()}",
                                style = MaterialTheme.typography.titleLarge,
                                fontWeight = FontWeight.Bold,
                                color = CleanTextPrimaryLight
                            )
                        }

                        Button(
                            onClick = {
                                if (!isProcessing) {
                                    isProcessing = true
                                    scope.launch {
                                        delay(1000) // Realistic payment authentication delay
                                        viewModel.placeCurrentOrder(selectedMethod) { order ->
                                            isProcessing = false
                                            onOrderPlaced(order)
                                        }
                                    }
                                }
                            },
                            enabled = !isProcessing && (selectedMethod != PaymentMethod.CAMPUS_WALLET || user.walletBalance >= grandTotal),
                            modifier = Modifier
                                .height(48.dp)
                                .testTag("pay_and_place_order_button"),
                            colors = ButtonDefaults.buttonColors(containerColor = CleanPurplePrimary),
                            shape = RoundedCornerShape(24.dp)
                        ) {
                            if (isProcessing) {
                                CircularProgressIndicator(
                                    modifier = Modifier.size(20.dp),
                                    color = Color.White,
                                    strokeWidth = 2.dp
                                )
                                Spacer(modifier = Modifier.width(8.dp))
                                Text("Processing...", color = Color.White, fontWeight = FontWeight.Bold)
                            } else {
                                Text(
                                    text = if (selectedMethod == PaymentMethod.PAY_AT_COUNTER) "Place Order (Pay Cash)" else "Pay ₹${grandTotal.toInt()} & Order",
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 14.sp,
                                    color = Color.White
                                )
                            }
                        }
                    }
                }
            }
        }
    ) { paddingValues ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(paddingValues)
                .padding(horizontal = 16.dp)
                .verticalScroll(rememberScrollState())
        ) {
            // Queue Confirmation Banner
            Card(
                modifier = Modifier.fillMaxWidth(),
                colors = CardDefaults.cardColors(
                    containerColor = if (selectedOrderType == OrderType.PRIORITY) PriorityDarkCard else CleanSurfaceLight
                ),
                shape = RoundedCornerShape(20.dp),
                border = androidx.compose.foundation.BorderStroke(
                    1.dp,
                    if (selectedOrderType == OrderType.PRIORITY) CleanPurplePrimary else CleanBorderSubtle.copy(alpha = 0.4f)
                )
            ) {
                Row(
                    modifier = Modifier.padding(16.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Box(
                        modifier = Modifier
                            .size(36.dp)
                            .background(
                                if (selectedOrderType == OrderType.PRIORITY) Color(0xFF6750A4) else CleanPurpleContainer,
                                CircleShape
                            ),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = if (selectedOrderType == OrderType.PRIORITY) Icons.Default.Bolt else Icons.Default.Payments,
                            contentDescription = null,
                            tint = if (selectedOrderType == OrderType.PRIORITY) Color.White else CleanPurplePrimary,
                            modifier = Modifier.size(18.dp)
                        )
                    }
                    Spacer(modifier = Modifier.width(12.dp))
                    Column {
                        Text(
                            text = if (selectedOrderType == OrderType.PRIORITY) "⚡ Priority Fast Lane" else "Standard Queue Order",
                            fontWeight = FontWeight.Bold,
                            fontSize = 14.sp,
                            color = if (selectedOrderType == OrderType.PRIORITY) Color.White else CleanTextPrimaryLight
                        )
                        Text(
                            text = if (selectedOrderType == OrderType.PRIORITY) "Ready in ~${surge.estimatedPriorityPrepMins} mins at Counter #2" else "Ready in ~${surge.estimatedNormalPrepMins} mins at Counter #1",
                            fontSize = 12.sp,
                            color = if (selectedOrderType == OrderType.PRIORITY) Color(0xFFEADDFF) else CleanTextSecondaryLight
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(16.dp))

            Text(
                text = "Payment Method",
                fontSize = 14.sp,
                fontWeight = FontWeight.Bold,
                color = CleanTextPrimaryLight
            )

            Spacer(modifier = Modifier.height(10.dp))

            // Option 1: Campus Wallet
            PaymentOptionCard(
                title = "Campus Wallet",
                subtitle = "Balance: ₹${user.walletBalance.toInt()} (${user.studentId})",
                icon = Icons.Default.AccountBalanceWallet,
                iconBg = CleanPurplePrimary,
                isSelected = selectedMethod == PaymentMethod.CAMPUS_WALLET,
                onClick = { selectedMethod = PaymentMethod.CAMPUS_WALLET },
                trailingContent = {
                    if (user.walletBalance < grandTotal) {
                        Text(
                            text = "Low Balance",
                            fontSize = 11.sp,
                            color = Color(0xFFB3261E),
                            fontWeight = FontWeight.Bold
                        )
                    }
                }
            )

            if (selectedMethod == PaymentMethod.CAMPUS_WALLET && user.walletBalance < grandTotal) {
                Spacer(modifier = Modifier.height(4.dp))
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.End
                ) {
                    TextButton(onClick = { viewModel.topUpWallet(200.0) }) {
                        Text("+ Quick Top-up ₹200", color = CleanPurplePrimary, fontWeight = FontWeight.Bold, fontSize = 12.sp)
                    }
                }
            }

            Spacer(modifier = Modifier.height(10.dp))

            // Option 2: UPI Apps
            PaymentOptionCard(
                title = "UPI Instant (GPay / PhonePe / Paytm)",
                subtitle = "Pay directly with UPI apps or scan QR",
                icon = Icons.Default.QrCode,
                iconBg = Color(0xFF6750A4),
                isSelected = selectedMethod in listOf(PaymentMethod.UPI_GPAY, PaymentMethod.UPI_PHONEPE, PaymentMethod.UPI_PAYTM),
                onClick = { selectedMethod = PaymentMethod.UPI_GPAY }
            )

            Spacer(modifier = Modifier.height(10.dp))

            // Option 3: Credit / Debit Card
            PaymentOptionCard(
                title = "Credit / Debit Card",
                subtitle = "Visa, MasterCard, RuPay cards accepted",
                icon = Icons.Default.CreditCard,
                iconBg = Color(0xFF7D5260),
                isSelected = selectedMethod == PaymentMethod.CARD,
                onClick = { selectedMethod = PaymentMethod.CARD }
            )

            Spacer(modifier = Modifier.height(10.dp))

            // Option 4: Pay at Counter
            PaymentOptionCard(
                title = "Pay Cash at Counter",
                subtitle = "Show token and pay cash when collecting",
                icon = Icons.Default.Storefront,
                iconBg = Color(0xFF49454F),
                isSelected = selectedMethod == PaymentMethod.PAY_AT_COUNTER,
                onClick = { selectedMethod = PaymentMethod.PAY_AT_COUNTER }
            )

            Spacer(modifier = Modifier.height(20.dp))

            // Security assurance
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(vertical = 12.dp),
                horizontalArrangement = Arrangement.Center,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Icon(
                    imageVector = Icons.Default.Lock,
                    contentDescription = null,
                    tint = Color(0xFF16A34A),
                    modifier = Modifier.size(14.dp)
                )
                Spacer(modifier = Modifier.width(6.dp))
                Text(
                    text = "Encrypted & Secure Campus Gateway",
                    fontSize = 12.sp,
                    color = CleanTextSecondaryLight
                )
            }

            Spacer(modifier = Modifier.height(24.dp))
        }
    }
}

@Composable
fun PaymentOptionCard(
    title: String,
    subtitle: String,
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    iconBg: Color,
    isSelected: Boolean,
    onClick: () -> Unit,
    trailingContent: (@Composable () -> Unit)? = null
) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(20.dp))
            .border(
                width = if (isSelected) 2.dp else 1.dp,
                color = if (isSelected) CleanPurplePrimary else CleanBorderSubtle.copy(alpha = 0.4f),
                shape = RoundedCornerShape(20.dp)
            )
            .clickable(onClick = onClick),
        colors = CardDefaults.cardColors(
            containerColor = if (isSelected) CleanPurpleContainer.copy(alpha = 0.4f) else CleanSurfaceLight
        )
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(14.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Box(
                modifier = Modifier
                    .size(36.dp)
                    .background(iconBg, RoundedCornerShape(10.dp)),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    imageVector = icon,
                    contentDescription = null,
                    tint = Color.White,
                    modifier = Modifier.size(18.dp)
                )
            }

            Spacer(modifier = Modifier.width(12.dp))

            Column(modifier = Modifier.weight(1f)) {
                Text(
                    text = title,
                    fontWeight = FontWeight.SemiBold,
                    fontSize = 14.sp,
                    color = CleanTextPrimaryLight
                )
                Text(
                    text = subtitle,
                    fontSize = 11.sp,
                    color = CleanTextSecondaryLight
                )
            }

            if (trailingContent != null) {
                trailingContent()
                Spacer(modifier = Modifier.width(8.dp))
            }

            RadioButton(
                selected = isSelected,
                onClick = onClick,
                colors = RadioButtonDefaults.colors(selectedColor = CleanPurplePrimary)
            )
        }
    }
}

package com.example.ui.screens

import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.Bolt
import androidx.compose.material.icons.filled.History
import androidx.compose.material.icons.filled.Replay
import androidx.compose.material.icons.filled.Star
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.ui.theme.CleanPurplePrimary
import com.example.ui.theme.CleanPurpleContainer
import com.example.ui.theme.CleanSurfaceLight
import com.example.ui.theme.CleanTextPrimaryLight
import com.example.ui.theme.CleanTextSecondaryLight
import com.example.ui.theme.CleanBorderSubtle
import com.example.ui.theme.SurgeGold
import com.example.ui.theme.VegGreen
import com.example.ui.theme.SurgePillBg
import com.example.ui.theme.SurgePillText
import com.example.ui.viewmodel.CanteenViewModel
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun OrderHistoryScreen(
    viewModel: CanteenViewModel,
    onBack: () -> Unit,
    onTrackOrder: (orderId: String) -> Unit,
    onReorder: () -> Unit,
    modifier: Modifier = Modifier
) {
    val orders by viewModel.allOrders.collectAsStateWithLifecycle()
    val allMenu by viewModel.allMenuItems.collectAsStateWithLifecycle()

    Scaffold(
        containerColor = MaterialTheme.colorScheme.background,
        topBar = {
            TopAppBar(
                title = {
                    Text(
                        text = "Order History & Receipts",
                        fontWeight = FontWeight.Bold,
                        style = MaterialTheme.typography.titleMedium,
                        color = CleanTextPrimaryLight
                    )
                },
                navigationIcon = {
                    IconButton(onClick = onBack) {
                        Icon(
                            imageVector = Icons.Default.ArrowBack,
                            contentDescription = "Back",
                            tint = CleanTextPrimaryLight
                        )
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = MaterialTheme.colorScheme.background
                )
            )
        }
    ) { paddingValues ->
        if (orders.isEmpty()) {
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(paddingValues)
                    .padding(24.dp),
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.Center
            ) {
                Text(text = "📜", fontSize = 56.sp)
                Spacer(modifier = Modifier.height(12.dp))
                Text(
                    text = "No Past Orders",
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.Bold,
                    color = CleanTextPrimaryLight
                )
                Text(
                    text = "Your past canteen tokens, receipts, and order logs will appear here.",
                    fontSize = 13.sp,
                    color = CleanTextSecondaryLight
                )
            }
        } else {
            LazyColumn(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(paddingValues)
                    .padding(horizontal = 16.dp)
                    .testTag("order_history_list"),
                verticalArrangement = Arrangement.spacedBy(14.dp)
            ) {
                items(orders, key = { it.orderId }) { order ->
                    val isPriority = order.orderType == "PRIORITY"

                    Card(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(20.dp))
                            .clickable {
                                viewModel.setTrackingOrderId(order.orderId)
                                onTrackOrder(order.orderId)
                            },
                        colors = CardDefaults.cardColors(containerColor = CleanSurfaceLight),
                        border = androidx.compose.foundation.BorderStroke(
                            1.dp,
                            if (isPriority) CleanPurplePrimary.copy(alpha = 0.35f) else CleanBorderSubtle.copy(alpha = 0.5f)
                        ),
                        elevation = CardDefaults.cardElevation(defaultElevation = 0.dp)
                    ) {
                        Column(modifier = Modifier.padding(16.dp)) {
                            // Header: Token + Status
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Text(
                                        text = "Token #${order.tokenNumber}",
                                        fontWeight = FontWeight.Bold,
                                        fontSize = 16.sp,
                                        color = if (isPriority) CleanPurplePrimary else CleanTextPrimaryLight
                                    )
                                    if (isPriority) {
                                        Spacer(modifier = Modifier.width(6.dp))
                                        Surface(
                                            color = SurgePillBg,
                                            shape = RoundedCornerShape(6.dp)
                                        ) {
                                            Row(
                                                modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp),
                                                verticalAlignment = Alignment.CenterVertically
                                            ) {
                                                Icon(
                                                    imageVector = Icons.Default.Bolt,
                                                    contentDescription = null,
                                                    tint = SurgePillText,
                                                    modifier = Modifier.size(12.dp)
                                                )
                                                Spacer(modifier = Modifier.width(2.dp))
                                                Text(
                                                    text = "PRIORITY",
                                                    color = SurgePillText,
                                                    fontSize = 9.sp,
                                                    fontWeight = FontWeight.Bold
                                                )
                                            }
                                        }
                                    }
                                }

                                Surface(
                                    color = when (order.orderStatus) {
                                        "READY" -> Color(0xFFE8F5E9)
                                        "PREPARING" -> CleanPurpleContainer
                                        "PICKED_UP" -> Color(0xFFF1F5F9)
                                        else -> CleanPurpleContainer.copy(alpha = 0.6f)
                                    },
                                    shape = RoundedCornerShape(6.dp)
                                ) {
                                    Text(
                                        text = order.orderStatus,
                                        fontSize = 11.sp,
                                        fontWeight = FontWeight.Bold,
                                        color = when (order.orderStatus) {
                                            "READY" -> VegGreen
                                            "PREPARING" -> CleanPurplePrimary
                                            "PICKED_UP" -> CleanTextSecondaryLight
                                            else -> CleanPurplePrimary
                                        },
                                        modifier = Modifier.padding(horizontal = 8.dp, vertical = 3.dp)
                                    )
                                }
                            }

                            Spacer(modifier = Modifier.height(4.dp))

                            Text(
                                text = SimpleDateFormat("dd MMM, hh:mm a", Locale.US).format(Date(order.createdAt)) + " • ${order.orderId}",
                                fontSize = 11.sp,
                                color = CleanTextSecondaryLight
                            )

                            Spacer(modifier = Modifier.height(8.dp))

                            // Items preview
                            Text(
                                text = order.itemsJson.replace(";", ", "),
                                fontSize = 13.sp,
                                color = CleanTextPrimaryLight,
                                maxLines = 2
                            )

                            if (order.rating > 0) {
                                Spacer(modifier = Modifier.height(6.dp))
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    (1..5).forEach { star ->
                                        Icon(
                                            imageVector = Icons.Default.Star,
                                            contentDescription = null,
                                            tint = if (star <= order.rating) SurgeGold else CleanBorderSubtle,
                                            modifier = Modifier.size(14.dp)
                                        )
                                    }
                                }
                            }

                            Spacer(modifier = Modifier.height(10.dp))
                            HorizontalDivider(color = CleanBorderSubtle.copy(alpha = 0.4f))
                            Spacer(modifier = Modifier.height(10.dp))

                            // Bottom actions
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text(
                                    text = "₹${order.totalAmount.toInt()}",
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 15.sp,
                                    color = CleanPurplePrimary
                                )

                                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                    OutlinedButton(
                                        onClick = {
                                            // Reorder logic: add items to cart
                                            val firstItem = allMenu.firstOrNull()
                                            if (firstItem != null) {
                                                viewModel.addToCart(firstItem, 1)
                                            }
                                            onReorder()
                                        },
                                        shape = RoundedCornerShape(12.dp),
                                        border = androidx.compose.foundation.BorderStroke(1.dp, CleanPurplePrimary)
                                    ) {
                                        Icon(
                                            imageVector = Icons.Default.Replay,
                                            contentDescription = null,
                                            modifier = Modifier.size(14.dp),
                                            tint = CleanPurplePrimary
                                        )
                                        Spacer(modifier = Modifier.width(4.dp))
                                        Text("Reorder", fontSize = 12.sp, color = CleanPurplePrimary)
                                    }

                                    Button(
                                        onClick = {
                                            viewModel.setTrackingOrderId(order.orderId)
                                            onTrackOrder(order.orderId)
                                        },
                                        colors = ButtonDefaults.buttonColors(containerColor = CleanPurplePrimary),
                                        shape = RoundedCornerShape(12.dp)
                                    ) {
                                        Text("View Live", fontSize = 12.sp, color = Color.White)
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}


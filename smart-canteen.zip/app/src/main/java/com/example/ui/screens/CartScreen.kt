package com.example.ui.screens

import androidx.compose.animation.animateColorAsState
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.Bolt
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.Remove
import androidx.compose.material.icons.filled.Schedule
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.data.model.OrderType
import com.example.ui.components.DietaryBadge
import com.example.ui.theme.CleanPurplePrimary
import com.example.ui.theme.CleanPurpleContainer
import com.example.ui.theme.CleanOnPurpleContainer
import com.example.ui.theme.CleanSurfaceLight
import com.example.ui.theme.CleanTextPrimaryLight
import com.example.ui.theme.CleanTextSecondaryLight
import com.example.ui.theme.CleanBorderSubtle
import com.example.ui.theme.PriorityDarkCard
import com.example.ui.theme.PrioritySubCard
import com.example.ui.theme.SurgeHighlightText
import com.example.ui.theme.SurgePillBg
import com.example.ui.theme.SurgePillText
import com.example.ui.viewmodel.CanteenViewModel

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun CartScreen(
    viewModel: CanteenViewModel,
    onBack: () -> Unit,
    onProceedToPayment: () -> Unit,
    modifier: Modifier = Modifier
) {
    val cart by viewModel.cart.collectAsStateWithLifecycle()
    val selectedOrderType by viewModel.selectedOrderType.collectAsStateWithLifecycle()
    val surge by viewModel.surgeCalculation.collectAsStateWithLifecycle()

    val itemTotal = cart.sumOf { it.totalPrice }
    val packagingFee = if (cart.isNotEmpty()) 10.0 else 0.0
    val priorityFee = if (selectedOrderType == OrderType.PRIORITY) surge.totalPriorityFee else 0.0
    val grandTotal = itemTotal + packagingFee + priorityFee

    Scaffold(
        containerColor = MaterialTheme.colorScheme.background,
        topBar = {
            TopAppBar(
                title = {
                    Text(
                        text = "Your Tray",
                        fontWeight = FontWeight.Bold,
                        fontSize = 18.sp,
                        color = CleanTextPrimaryLight
                    )
                },
                navigationIcon = {
                    IconButton(onClick = onBack) {
                        Icon(imageVector = Icons.Default.ArrowBack, contentDescription = "Back", tint = CleanTextPrimaryLight)
                    }
                },
                actions = {
                    if (cart.isNotEmpty()) {
                        TextButton(onClick = { viewModel.clearCart() }) {
                            Text("Clear", color = Color(0xFFB3261E), fontWeight = FontWeight.Bold, fontSize = 13.sp)
                        }
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = MaterialTheme.colorScheme.background
                )
            )
        },
        bottomBar = {
            if (cart.isNotEmpty()) {
                Surface(
                    color = CleanSurfaceLight,
                    shadowElevation = 8.dp,
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(16.dp)
                    ) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column {
                                Text(
                                    text = "Total to Pay",
                                    fontSize = 12.sp,
                                    color = CleanTextSecondaryLight
                                )
                                Text(
                                    text = "₹${grandTotal.toInt()}",
                                    style = MaterialTheme.typography.titleLarge,
                                    fontWeight = FontWeight.Bold,
                                    color = CleanTextPrimaryLight
                                )
                            }

                            Button(
                                onClick = onProceedToPayment,
                                modifier = Modifier
                                    .height(48.dp)
                                    .testTag("checkout_button"),
                                colors = ButtonDefaults.buttonColors(
                                    containerColor = CleanPurplePrimary
                                ),
                                shape = RoundedCornerShape(24.dp)
                            ) {
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    if (selectedOrderType == OrderType.PRIORITY) {
                                        Icon(
                                            imageVector = Icons.Default.Bolt,
                                            contentDescription = null,
                                            tint = Color.White,
                                            modifier = Modifier.size(16.dp)
                                        )
                                        Spacer(modifier = Modifier.width(4.dp))
                                    }
                                    Text(
                                        text = if (selectedOrderType == OrderType.PRIORITY) "Priority Checkout" else "Normal Checkout",
                                        fontWeight = FontWeight.Bold,
                                        fontSize = 14.sp,
                                        color = Color.White
                                    )
                                }
                            }
                        }
                    }
                }
            }
        }
    ) { paddingValues ->
        if (cart.isEmpty()) {
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(paddingValues)
                    .padding(24.dp),
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.Center
            ) {
                Text(text = "🛒", fontSize = 56.sp)
                Spacer(modifier = Modifier.height(14.dp))
                Text(
                    text = "Your tray is empty",
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.Bold,
                    color = CleanTextPrimaryLight
                )
                Spacer(modifier = Modifier.height(6.dp))
                Text(
                    text = "Explore the menu to add delicious meals, snacks, and drinks.",
                    fontSize = 13.sp,
                    color = CleanTextSecondaryLight,
                    textAlign = androidx.compose.ui.text.style.TextAlign.Center
                )
                Spacer(modifier = Modifier.height(20.dp))
                Button(
                    onClick = onBack,
                    colors = ButtonDefaults.buttonColors(containerColor = CleanPurplePrimary),
                    shape = RoundedCornerShape(20.dp)
                ) {
                    Text("Explore Menu", fontWeight = FontWeight.Bold, color = Color.White)
                }
            }
        } else {
            LazyColumn(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(paddingValues)
                    .padding(horizontal = 16.dp),
                verticalArrangement = Arrangement.spacedBy(14.dp)
            ) {
                // Cart items list
                item {
                    Text(
                        text = "Items in Order",
                        fontSize = 14.sp,
                        fontWeight = FontWeight.Bold,
                        color = CleanTextPrimaryLight,
                        modifier = Modifier.padding(top = 4.dp)
                    )
                }

                items(cart) { cartItem ->
                    Card(
                        modifier = Modifier.fillMaxWidth(),
                        colors = CardDefaults.cardColors(containerColor = CleanSurfaceLight),
                        shape = RoundedCornerShape(20.dp),
                        elevation = CardDefaults.cardElevation(defaultElevation = 0.dp)
                    ) {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(14.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            DietaryBadge(dietaryType = cartItem.menuItem.dietaryType)
                            Spacer(modifier = Modifier.width(10.dp))
                            Column(modifier = Modifier.weight(1f)) {
                                Text(
                                    text = cartItem.menuItem.name,
                                    fontWeight = FontWeight.SemiBold,
                                    fontSize = 14.sp,
                                    color = CleanTextPrimaryLight
                                )
                                if (cartItem.selectedAddOns.isNotEmpty()) {
                                    Text(
                                        text = "+ ${cartItem.selectedAddOns.joinToString { it.name }}",
                                        fontSize = 11.sp,
                                        color = CleanTextSecondaryLight
                                    )
                                }
                                if (cartItem.specialNotes.isNotBlank()) {
                                    Text(
                                        text = "Note: ${cartItem.specialNotes}",
                                        fontSize = 11.sp,
                                        color = CleanPurplePrimary
                                    )
                                }
                                Spacer(modifier = Modifier.height(2.dp))
                                Text(
                                    text = "₹${cartItem.totalPrice.toInt()}",
                                    fontSize = 13.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = CleanTextPrimaryLight
                                )
                            }

                            // Stepper
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                modifier = Modifier
                                    .background(Color(0xFFEADDFF).copy(alpha = 0.4f), RoundedCornerShape(16.dp))
                                    .padding(horizontal = 4.dp, vertical = 2.dp)
                            ) {
                                IconButton(
                                    onClick = { viewModel.updateCartQuantity(cartItem, cartItem.quantity - 1) },
                                    modifier = Modifier.size(28.dp)
                                ) {
                                    Icon(
                                        imageVector = if (cartItem.quantity == 1) Icons.Default.Delete else Icons.Default.Remove,
                                        contentDescription = "Decrease",
                                        modifier = Modifier.size(14.dp),
                                        tint = if (cartItem.quantity == 1) Color(0xFFB3261E) else CleanTextPrimaryLight
                                    )
                                }
                                Text(
                                    text = "${cartItem.quantity}",
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 13.sp,
                                    color = CleanTextPrimaryLight,
                                    modifier = Modifier.padding(horizontal = 6.dp)
                                )
                                IconButton(
                                    onClick = { viewModel.updateCartQuantity(cartItem, cartItem.quantity + 1) },
                                    modifier = Modifier.size(28.dp)
                                ) {
                                    Icon(
                                        imageVector = Icons.Default.Add,
                                        contentDescription = "Increase",
                                        tint = CleanTextPrimaryLight,
                                        modifier = Modifier.size(14.dp)
                                    )
                                }
                            }
                        }
                    }
                }

                // QUEUE SPEED SELECTION (Surge Pricing Engine)
                item {
                    Spacer(modifier = Modifier.height(4.dp))
                    Text(
                        text = "Pickup Lane",
                        fontSize = 14.sp,
                        fontWeight = FontWeight.Bold,
                        color = CleanTextPrimaryLight
                    )
                    Spacer(modifier = Modifier.height(6.dp))

                    // Option 1: PRIORITY PICKUP FAST LANE
                    val isPrioritySelected = selectedOrderType == OrderType.PRIORITY
                    Card(
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("priority_queue_option")
                            .clip(RoundedCornerShape(20.dp))
                            .border(
                                width = if (isPrioritySelected) 2.dp else 1.dp,
                                color = if (isPrioritySelected) CleanPurplePrimary else CleanBorderSubtle.copy(alpha = 0.4f),
                                shape = RoundedCornerShape(20.dp)
                            )
                            .clickable { viewModel.setOrderType(OrderType.PRIORITY) },
                        colors = CardDefaults.cardColors(
                            containerColor = if (isPrioritySelected) PriorityDarkCard else CleanSurfaceLight
                        )
                    ) {
                        Column(modifier = Modifier.padding(16.dp)) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Box(
                                        modifier = Modifier
                                            .size(36.dp)
                                            .background(if (isPrioritySelected) Color(0xFF6750A4) else CleanPurpleContainer, CircleShape),
                                        contentAlignment = Alignment.Center
                                    ) {
                                        Icon(
                                            imageVector = Icons.Default.Bolt,
                                            contentDescription = null,
                                            tint = if (isPrioritySelected) Color.White else CleanPurplePrimary,
                                            modifier = Modifier.size(18.dp)
                                        )
                                    }
                                    Spacer(modifier = Modifier.width(10.dp))
                                    Column {
                                        Row(verticalAlignment = Alignment.CenterVertically) {
                                            Text(
                                                text = "Priority Fast Lane",
                                                style = MaterialTheme.typography.titleSmall,
                                                fontWeight = FontWeight.Bold,
                                                color = if (isPrioritySelected) Color.White else CleanTextPrimaryLight
                                            )
                                            Spacer(modifier = Modifier.width(6.dp))
                                            Surface(
                                                color = if (isPrioritySelected) SurgePillBg else CleanPurpleContainer,
                                                shape = RoundedCornerShape(4.dp)
                                            ) {
                                                Text(
                                                    text = "SURGE",
                                                    color = if (isPrioritySelected) SurgePillText else CleanPurplePrimary,
                                                    fontSize = 9.sp,
                                                    fontWeight = FontWeight.Bold,
                                                    modifier = Modifier.padding(horizontal = 4.dp, vertical = 2.dp)
                                                )
                                            }
                                        }
                                        Text(
                                            text = "Express prep at Counter #2",
                                            fontSize = 12.sp,
                                            color = if (isPrioritySelected) Color(0xFFEADDFF) else CleanTextSecondaryLight
                                        )
                                    }
                                }

                                Text(
                                    text = "+₹${surge.totalPriorityFee.toInt()}",
                                    style = MaterialTheme.typography.titleMedium,
                                    fontWeight = FontWeight.Bold,
                                    color = if (isPrioritySelected) SurgeHighlightText else CleanPurplePrimary
                                )
                            }

                            Spacer(modifier = Modifier.height(10.dp))
                            HorizontalDivider(color = if (isPrioritySelected) Color(0xFFEADDFF).copy(alpha = 0.2f) else CleanBorderSubtle.copy(alpha = 0.4f))
                            Spacer(modifier = Modifier.height(8.dp))

                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text(
                                    text = "⏱️ Ready in ~${surge.estimatedPriorityPrepMins} mins",
                                    fontSize = 12.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = if (isPrioritySelected) Color.White else CleanTextPrimaryLight
                                )
                                Text(
                                    text = "${surge.pendingOrdersCount} orders ahead",
                                    fontSize = 11.sp,
                                    color = if (isPrioritySelected) Color(0xFFEADDFF) else CleanTextSecondaryLight
                                )
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(10.dp))

                    // Option 2: NORMAL QUEUE (Free)
                    val isNormalSelected = selectedOrderType == OrderType.NORMAL
                    Card(
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("normal_queue_option")
                            .clip(RoundedCornerShape(20.dp))
                            .border(
                                width = if (isNormalSelected) 2.dp else 1.dp,
                                color = if (isNormalSelected) CleanPurplePrimary else CleanBorderSubtle.copy(alpha = 0.4f),
                                shape = RoundedCornerShape(20.dp)
                            )
                            .clickable { viewModel.setOrderType(OrderType.NORMAL) },
                        colors = CardDefaults.cardColors(
                            containerColor = if (isNormalSelected) CleanPurpleContainer.copy(alpha = 0.4f) else CleanSurfaceLight
                        )
                    ) {
                        Column(modifier = Modifier.padding(16.dp)) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Box(
                                        modifier = Modifier
                                            .size(36.dp)
                                            .background(CleanSurfaceLight, CircleShape),
                                        contentAlignment = Alignment.Center
                                    ) {
                                        Icon(
                                            imageVector = Icons.Default.Schedule,
                                            contentDescription = null,
                                            tint = CleanTextSecondaryLight,
                                            modifier = Modifier.size(18.dp)
                                        )
                                    }
                                    Spacer(modifier = Modifier.width(10.dp))
                                    Column {
                                        Text(
                                            text = "Standard Queue",
                                            style = MaterialTheme.typography.titleSmall,
                                            fontWeight = FontWeight.Bold,
                                            color = CleanTextPrimaryLight
                                        )
                                        Text(
                                            text = "Processed in regular queue",
                                            fontSize = 12.sp,
                                            color = CleanTextSecondaryLight
                                        )
                                    }
                                }

                                Text(
                                    text = "FREE",
                                    style = MaterialTheme.typography.titleMedium,
                                    fontWeight = FontWeight.Bold,
                                    color = Color(0xFF16A34A)
                                )
                            }

                            Spacer(modifier = Modifier.height(10.dp))
                            HorizontalDivider(color = CleanBorderSubtle.copy(alpha = 0.4f))
                            Spacer(modifier = Modifier.height(8.dp))

                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text(
                                    text = "⏱️ Ready in ~${surge.estimatedNormalPrepMins} mins",
                                    fontSize = 12.sp,
                                    color = CleanTextSecondaryLight
                                )
                                Text(
                                    text = "Position #${surge.pendingOrdersCount + 1}",
                                    fontSize = 11.sp,
                                    color = CleanTextSecondaryLight
                                )
                            }
                        }
                    }
                }

                // Surge Calculation Transparency Note
                if (selectedOrderType == OrderType.PRIORITY) {
                    item {
                        Surface(
                            color = CleanPurpleContainer.copy(alpha = 0.5f),
                            shape = RoundedCornerShape(16.dp),
                            border = androidx.compose.foundation.BorderStroke(1.dp, CleanBorderSubtle.copy(alpha = 0.3f))
                        ) {
                            Row(
                                modifier = Modifier.padding(12.dp),
                                verticalAlignment = Alignment.Top
                            ) {
                                Icon(
                                    imageVector = Icons.Default.Info,
                                    contentDescription = null,
                                    tint = CleanPurplePrimary,
                                    modifier = Modifier.size(16.dp)
                                )
                                Spacer(modifier = Modifier.width(8.dp))
                                Column {
                                    Text(
                                        text = "Surge Pricing",
                                        fontWeight = FontWeight.Bold,
                                        fontSize = 12.sp,
                                        color = CleanTextPrimaryLight
                                    )
                                    Spacer(modifier = Modifier.height(2.dp))
                                    Text(
                                        text = surge.explanation,
                                        fontSize = 11.sp,
                                        color = CleanTextSecondaryLight,
                                        lineHeight = 15.sp
                                    )
                                }
                            }
                        }
                    }
                }

                // Detailed Bill Breakdown
                item {
                    Card(
                        modifier = Modifier.fillMaxWidth(),
                        colors = CardDefaults.cardColors(containerColor = CleanSurfaceLight),
                        shape = RoundedCornerShape(20.dp)
                    ) {
                        Column(modifier = Modifier.padding(16.dp)) {
                            Text(
                                text = "Bill Details",
                                style = MaterialTheme.typography.titleSmall,
                                fontWeight = FontWeight.Bold,
                                color = CleanTextPrimaryLight
                            )
                            Spacer(modifier = Modifier.height(10.dp))

                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween
                            ) {
                                Text("Item Total", fontSize = 13.sp, color = CleanTextSecondaryLight)
                                Text("₹${itemTotal.toInt()}", fontSize = 13.sp, fontWeight = FontWeight.SemiBold, color = CleanTextPrimaryLight)
                            }

                            Spacer(modifier = Modifier.height(6.dp))

                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween
                            ) {
                                Text("Canteen Packaging", fontSize = 13.sp, color = CleanTextSecondaryLight)
                                Text("₹${packagingFee.toInt()}", fontSize = 13.sp, fontWeight = FontWeight.SemiBold, color = CleanTextPrimaryLight)
                            }

                            if (selectedOrderType == OrderType.PRIORITY) {
                                Spacer(modifier = Modifier.height(6.dp))
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceBetween
                                ) {
                                    Row(verticalAlignment = Alignment.CenterVertically) {
                                        Text("Priority Rush Fee", fontSize = 13.sp, color = CleanPurplePrimary, fontWeight = FontWeight.Bold)
                                        Spacer(modifier = Modifier.width(4.dp))
                                        Icon(imageVector = Icons.Default.Bolt, contentDescription = null, tint = CleanPurplePrimary, modifier = Modifier.size(14.dp))
                                    }
                                    Text("₹${priorityFee.toInt()}", fontSize = 13.sp, color = CleanPurplePrimary, fontWeight = FontWeight.Bold)
                                }
                            }

                            Spacer(modifier = Modifier.height(10.dp))
                            HorizontalDivider(color = CleanBorderSubtle.copy(alpha = 0.4f))
                            Spacer(modifier = Modifier.height(10.dp))

                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween
                            ) {
                                Text("Grand Total", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold, color = CleanTextPrimaryLight)
                                Text("₹${grandTotal.toInt()}", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold, color = CleanPurplePrimary)
                            }
                        }
                    }
                }

                item {
                    Spacer(modifier = Modifier.height(24.dp))
                }
            }
        }
    }
}


package com.example.ui.viewmodel

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.local.CanteenDatabase
import com.example.data.local.MenuItemEntity
import com.example.data.local.OrderEntity
import com.example.data.local.SeedData
import com.example.data.local.SurgeConfigEntity
import com.example.data.local.UserEntity
import com.example.data.model.AddOnOption
import com.example.data.model.CartItem
import com.example.data.model.DietaryType
import com.example.data.model.OrderStatus
import com.example.data.model.OrderType
import com.example.data.model.PaymentMethod
import com.example.data.model.SurgeCalculation
import com.example.data.model.UserRole
import com.example.data.repository.CanteenRepository
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch

class CanteenViewModel(application: Application) : AndroidViewModel(application) {

    private val repository = CanteenRepository(CanteenDatabase.getDatabase(application))

    // Flows from repository
    val allMenuItems: StateFlow<List<MenuItemEntity>> = repository.getAllMenuItems()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val pendingOrdersCount: StateFlow<Int> = repository.getPendingOrdersCountFlow()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), 0)

    val surgeConfig: StateFlow<SurgeConfigEntity> = repository.getSurgeConfigFlow()
        .combine(MutableStateFlow(SeedData.defaultSurgeConfig)) { config, fallback ->
            config ?: fallback
        }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), SeedData.defaultSurgeConfig)

    val activeKitchenOrders: StateFlow<List<OrderEntity>> = repository.getActiveKitchenOrders()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val allOrders: StateFlow<List<OrderEntity>> = repository.getAllOrders()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val currentUser: StateFlow<UserEntity> = repository.getUserFlow("user_student_1")
        .combine(MutableStateFlow(SeedData.defaultUser)) { user, fallback ->
            user ?: fallback
        }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), SeedData.defaultUser)

    val totalRevenue: StateFlow<Double> = repository.getTotalRevenueFlow()
        .combine(MutableStateFlow(0.0)) { rev, _ -> rev ?: 0.0 }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), 0.0)

    val totalSurgeRevenue: StateFlow<Double> = repository.getTotalSurgeRevenueFlow()
        .combine(MutableStateFlow(0.0)) { rev, _ -> rev ?: 0.0 }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), 0.0)

    val totalPriorityOrdersCount: StateFlow<Int> = repository.getTotalPriorityOrdersCountFlow()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), 0)

    // Dynamic Surge Calculation Flow
    val surgeCalculation: StateFlow<SurgeCalculation> = combine(
        surgeConfig,
        pendingOrdersCount
    ) { config, count ->
        SurgeCalculation.calculate(config, count)
    }.stateIn(
        viewModelScope,
        SharingStarted.WhileSubscribed(5000),
        SurgeCalculation.calculate(SeedData.defaultSurgeConfig, 0)
    )

    // UI state
    private val _searchQuery = MutableStateFlow("")
    val searchQuery = _searchQuery.asStateFlow()

    private val _selectedCategory = MutableStateFlow("All")
    val selectedCategory = _selectedCategory.asStateFlow()

    private val _selectedDietaryFilter = MutableStateFlow<DietaryType?>(null)
    val selectedDietaryFilter = _selectedDietaryFilter.asStateFlow()

    private val _inStockOnly = MutableStateFlow(false)
    val inStockOnly = _inStockOnly.asStateFlow()

    private val _cart = MutableStateFlow<List<CartItem>>(emptyList())
    val cart = _cart.asStateFlow()

    private val _selectedOrderType = MutableStateFlow(OrderType.NORMAL)
    val selectedOrderType = _selectedOrderType.asStateFlow()

    private val _detailItem = MutableStateFlow<MenuItemEntity?>(null)
    val detailItem = _detailItem.asStateFlow()

    private val _currentActiveOrderId = MutableStateFlow<String?>(null)
    val currentActiveOrderId = _currentActiveOrderId.asStateFlow()

    private val _activeNotification = MutableStateFlow<String?>(null)
    val activeNotification = _activeNotification.asStateFlow()

    private val _activeUserRole = MutableStateFlow(UserRole.CUSTOMER)
    val activeUserRole = _activeUserRole.asStateFlow()
    val currentUserRole: StateFlow<UserRole> = activeUserRole


    // Filtered menu list for customer
    val filteredMenuItems: StateFlow<List<MenuItemEntity>> = combine(
        allMenuItems,
        searchQuery,
        selectedCategory,
        selectedDietaryFilter,
        inStockOnly
    ) { items, query, category, dietary, stockOnly ->
        items.filter { item ->
            val matchesQuery = query.isBlank() ||
                    item.name.contains(query, ignoreCase = true) ||
                    item.description.contains(query, ignoreCase = true) ||
                    item.category.contains(query, ignoreCase = true)

            val matchesCategory = category == "All" ||
                    (category == "Popular Rush" && item.isPopularRushItem) ||
                    item.category.equals(category, ignoreCase = true)

            val matchesDietary = dietary == null || item.dietaryType.equals(dietary.name, ignoreCase = true)

            val matchesStock = !stockOnly || (item.isAvailable && item.stockQuantity > 0)

            matchesQuery && matchesCategory && matchesDietary && matchesStock
        }
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    // Filtered customer orders for history/tracking
    val customerOrders: StateFlow<List<OrderEntity>> = combine(
        allOrders,
        currentUser
    ) { orders, user ->
        orders.filter { it.customerName == user.name || it.customerPhone == user.phone }
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    // Active order being tracked
    val trackingOrder: StateFlow<OrderEntity?> = combine(
        allOrders,
        currentActiveOrderId
    ) { orders, activeId ->
        if (activeId != null) {
            orders.find { it.orderId == activeId }
        } else {
            // Find most recent uncompleted order for customer
            orders.find { it.customerName == currentUser.value.name && it.orderStatus != OrderStatus.PICKED_UP.name }
        }
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), null)

    // User Actions
    fun setSearchQuery(query: String) {
        _searchQuery.value = query
    }

    fun setSelectedCategory(category: String) {
        _selectedCategory.value = category
    }

    fun setDietaryFilter(dietary: DietaryType?) {
        _selectedDietaryFilter.value = dietary
    }

    fun toggleInStockOnly() {
        _inStockOnly.update { !it }
    }

    fun openItemDetail(item: MenuItemEntity) {
        _detailItem.value = item
    }

    fun closeItemDetail() {
        _detailItem.value = null
    }

    fun setOrderType(orderType: OrderType) {
        _selectedOrderType.value = orderType
    }

    fun addToCart(item: MenuItemEntity, quantity: Int = 1, addOns: List<AddOnOption> = emptyList(), notes: String = "") {
        _cart.update { currentCart ->
            val existingIndex = currentCart.indexOfFirst {
                it.menuItem.id == item.id && it.selectedAddOns == addOns && it.specialNotes == notes
            }
            if (existingIndex >= 0) {
                val existing = currentCart[existingIndex]
                val updated = currentCart.toMutableList()
                updated[existingIndex] = existing.copy(quantity = existing.quantity + quantity)
                updated
            } else {
                currentCart + CartItem(
                    menuItem = item,
                    quantity = quantity,
                    selectedAddOns = addOns,
                    specialNotes = notes
                )
            }
        }
    }

    fun updateCartQuantity(item: CartItem, newQty: Int) {
        _cart.update { currentCart ->
            if (newQty <= 0) {
                currentCart.filter { it != item }
            } else {
                currentCart.map {
                    if (it == item) it.copy(quantity = newQty) else it
                }
            }
        }
    }

    fun clearCart() {
        _cart.value = emptyList()
    }

    fun placeCurrentOrder(
        paymentMethod: PaymentMethod,
        onSuccess: (OrderEntity) -> Unit
    ) {
        val currentItems = _cart.value
        if (currentItems.isEmpty()) return

        val user = currentUser.value
        val orderType = _selectedOrderType.value
        val surge = surgeCalculation.value
        val priorityFee = if (orderType == OrderType.PRIORITY) surge.totalPriorityFee else 0.0
        val taxesAndFees = 10.0 // standard packaging & campus convenience

        viewModelScope.launch {
            val order = repository.placeOrder(
                customerName = user.name,
                customerPhone = user.phone,
                items = currentItems,
                orderType = orderType,
                paymentMethod = paymentMethod,
                priorityFee = priorityFee,
                taxesAndFees = taxesAndFees
            )
            _cart.value = emptyList()
            _currentActiveOrderId.value = order.orderId
            _activeNotification.value = "Order placed! Token #${order.tokenNumber} is in the ${if (orderType == OrderType.PRIORITY) "⚡ Express Priority Lane" else "Standard Queue"}."
            onSuccess(order)
        }
    }

    fun setTrackingOrderId(orderId: String?) {
        _currentActiveOrderId.value = orderId
    }

    fun dismissNotification() {
        _activeNotification.value = null
    }

    fun rateOrder(orderId: String, rating: Float, comment: String) {
        viewModelScope.launch {
            repository.rateOrder(orderId, rating, comment)
        }
    }

    fun topUpWallet(amount: Double) {
        viewModelScope.launch {
            repository.topUpWallet(amount)
        }
    }

    fun switchRole(role: UserRole) {
        _activeUserRole.value = role
    }

    fun setUserRole(role: UserRole) {
        _activeUserRole.value = role
    }


    // Admin Actions
    fun advanceOrderStatus(orderId: String, currentStatus: String) {
        viewModelScope.launch {
            val nextStatus = when (currentStatus) {
                OrderStatus.PLACED.name -> OrderStatus.ACCEPTED
                OrderStatus.ACCEPTED.name -> OrderStatus.PREPARING
                OrderStatus.PREPARING.name -> OrderStatus.READY
                OrderStatus.READY.name -> OrderStatus.PICKED_UP
                else -> OrderStatus.PICKED_UP
            }
            repository.updateOrderStatus(orderId, nextStatus)

            if (nextStatus == OrderStatus.READY) {
                _activeNotification.value = "🔔 ORDER READY: Order $orderId is ready for counter pickup!"
            }
        }
    }

    fun updateMenuItemStock(id: Long, newStock: Int) {
        viewModelScope.launch {
            repository.updateMenuItemStock(id, newStock)
        }
    }

    fun toggleMenuItemAvailability(id: Long, currentAvailable: Boolean) {
        viewModelScope.launch {
            repository.updateMenuItemAvailability(id, !currentAvailable)
        }
    }

    fun saveMenuItem(item: MenuItemEntity) {
        viewModelScope.launch {
            repository.saveMenuItem(item)
        }
    }

    fun deleteMenuItem(id: Long) {
        viewModelScope.launch {
            repository.deleteMenuItem(id)
        }
    }

    fun updateSurgeConfig(config: SurgeConfigEntity) {
        viewModelScope.launch {
            repository.updateSurgeConfig(config)
        }
    }

    fun simulateIncomingRushOrder() {
        viewModelScope.launch {
            repository.simulateRushOrder()
            _activeNotification.value = "⚡ Simulated rush order arrived! Queue count updated."
        }
    }
}

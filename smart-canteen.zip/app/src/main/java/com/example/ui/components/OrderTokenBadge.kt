package com.example.ui.components

import androidx.compose.animation.animateColorAsState
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Bolt
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Schedule
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.local.OrderEntity
import com.example.ui.theme.CleanPurplePrimary
import com.example.ui.theme.CleanPurpleContainer
import com.example.ui.theme.CleanSurfaceLight
import com.example.ui.theme.CleanTextPrimaryLight
import com.example.ui.theme.CleanTextSecondaryLight
import com.example.ui.theme.CleanBorderSubtle
import com.example.ui.theme.PriorityDarkCard
import com.example.ui.theme.PrioritySubCard
import com.example.ui.theme.SurgeHighlightText
import com.example.ui.theme.SurgePillBg
import com.example.ui.theme.SurgePillText

@Composable
fun OrderTokenBadge(
    order: OrderEntity,
    modifier: Modifier = Modifier
) {
    val isPriority = order.orderType == "PRIORITY"

    Card(
        modifier = modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(24.dp))
            .border(
                width = if (isPriority) 2.dp else 1.dp,
                color = if (isPriority) CleanPurplePrimary else CleanBorderSubtle.copy(alpha = 0.4f),
                shape = RoundedCornerShape(24.dp)
            ),
        colors = CardDefaults.cardColors(
            containerColor = if (isPriority) PriorityDarkCard else CleanSurfaceLight
        ),
        elevation = CardDefaults.cardElevation(defaultElevation = 0.dp)
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(20.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                if (isPriority) {
                    Surface(
                        color = SurgePillBg,
                        shape = RoundedCornerShape(6.dp)
                    ) {
                        Row(
                            modifier = Modifier.padding(horizontal = 8.dp, vertical = 3.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Icon(
                                imageVector = Icons.Default.Bolt,
                                contentDescription = null,
                                tint = SurgePillText,
                                modifier = Modifier.size(12.dp)
                            )
                            Spacer(modifier = Modifier.width(3.dp))
                            Text(
                                text = "PRIORITY LANE",
                                color = SurgePillText,
                                fontSize = 10.sp,
                                fontWeight = FontWeight.Bold
                            )
                        }
                    }
                } else {
                    Surface(
                        color = CleanPurpleContainer.copy(alpha = 0.5f),
                        shape = RoundedCornerShape(6.dp)
                    ) {
                        Text(
                            text = "STANDARD QUEUE",
                            color = CleanPurplePrimary,
                            fontSize = 10.sp,
                            fontWeight = FontWeight.Bold,
                            modifier = Modifier.padding(horizontal = 8.dp, vertical = 3.dp)
                        )
                    }
                }

                Text(
                    text = "ID: ${order.orderId}",
                    fontSize = 12.sp,
                    fontFamily = FontFamily.Monospace,
                    color = if (isPriority) Color(0xFFEADDFF) else CleanTextSecondaryLight
                )
            }

            Spacer(modifier = Modifier.height(14.dp))

            Text(
                text = "YOUR PICKUP TOKEN",
                fontSize = 11.sp,
                fontWeight = FontWeight.Bold,
                letterSpacing = 2.sp,
                color = if (isPriority) Color(0xFFEADDFF) else CleanTextSecondaryLight
            )

            Spacer(modifier = Modifier.height(4.dp))

            Text(
                text = order.tokenNumber,
                fontSize = 44.sp,
                fontWeight = FontWeight.Bold,
                fontFamily = FontFamily.Monospace,
                color = if (isPriority) SurgeHighlightText else CleanTextPrimaryLight
            )

            Spacer(modifier = Modifier.height(8.dp))

            // Counter Assignment
            Surface(
                color = if (isPriority) PrioritySubCard else CleanPurpleContainer.copy(alpha = 0.4f),
                shape = RoundedCornerShape(12.dp)
            ) {
                Row(
                    modifier = Modifier.padding(horizontal = 14.dp, vertical = 8.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = if (isPriority) "⚡ Collect at Counter #${order.counterNumber} (Express Lane)"
                        else "🍽️ Collect at Counter #${order.counterNumber} (Standard Line)",
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Bold,
                        color = if (isPriority) Color.White else CleanPurplePrimary
                    )
                }
            }
        }
    }
}


package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Clean Minimalism Primary Palette
val CleanPurplePrimary = Color(0xFF6750A4)
val CleanPurpleDark = Color(0xFF21005D)
val CleanPurpleLight = Color(0xFFD0BCFF)
val CleanPurpleContainer = Color(0xFFEADDFF)
val CleanOnPurpleContainer = Color(0xFF21005D)

// Surge & Priority Accent (Clean Minimalism Deep Purple & Rose)
val PriorityDarkCard = Color(0xFF21005D)
val PrioritySubCard = Color(0xFF381E72)
val SurgePillBg = Color(0xFFFFD8E4)
val SurgePillText = Color(0xFF31111D)
val SurgeHighlightText = Color(0xFFD0BCFF)

// Category & Status Indicators
val VegGreen = Color(0xFF16A34A)
val VegGreenBg = Color(0xFFDCFCE7)
val NonVegRed = Color(0xFFDC2626)
val NonVegRedBg = Color(0xFFFEE2E2)
val VeganPurple = Color(0xFF6750A4)
val VeganPurpleBg = Color(0xFFEADDFF)

// Clean Minimalism Surfaces & Neutrals
val CleanBackgroundLight = Color(0xFFFEF7FF)
val CleanSurfaceLight = Color(0xFFF3EDF7)
val CleanSurfaceCardLight = Color(0xFFF7F2FA)
val CleanTextPrimaryLight = Color(0xFF1D1B20)
val CleanTextSecondaryLight = Color(0xFF49454F)
val CleanBorderSubtle = Color(0xFFCAC4D0)

val DarkBackground = Color(0xFF141218)
val DarkSurface = Color(0xFF1D1B20)
val DarkSurfaceVariant = Color(0xFF2B2830)
val TextPrimaryDark = Color(0xFFE6E1E5)
val TextSecondaryDark = Color(0xFFCAC4D0)

// Backward compatible aliases
val CanteenOrangePrimary = CleanPurplePrimary
val CanteenOrangeDark = CleanPurpleDark
val CanteenOrangeLight = CleanPurpleLight
val CanteenOrangeContainer = CleanPurpleContainer
val CanteenOnOrangeContainer = CleanOnPurpleContainer
val SurgeGold = Color(0xFF7D5260)
val SurgeGoldLight = Color(0xFFFFD8E4)
val SurgeGoldDark = Color(0xFF31111D)
val SurgeRed = Color(0xFFB3261E)
val SurgeRedLight = Color(0xFFF9DEDC)
val WarmBackgroundLight = CleanBackgroundLight
val WarmSurfaceLight = CleanSurfaceLight
val WarmSurfaceVariantLight = CleanSurfaceCardLight
val TextPrimaryLight = CleanTextPrimaryLight
val TextSecondaryLight = CleanTextSecondaryLight

